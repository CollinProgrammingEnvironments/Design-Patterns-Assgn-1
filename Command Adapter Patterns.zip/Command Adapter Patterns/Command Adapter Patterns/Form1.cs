﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command_Adapter_Patterns
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Receiver calculation = null;
        Command command = null;
        AddCommand addCommand = null;
        SubtractCommand subCommand = null;
        MultiplicationCommand multCommand = null;
        DivideCommand divCommand = null;
        
        Target target = null;
        Adapter adapter = null;

        private void Form1_Load(object sender, EventArgs e)
        {
            /*int x = m_tbNumber1.Text.ParseInt();
            int y = m_tbNumber2.Text.ParseInt();

            calculation = new Invoker(x, y);

            addCommand = new AddCommand(calculation);
            subCommand = new SubtractCommand(calculation);
            multCommand = new MultiplicationCommand(calculation);
            divCommand = new DivideCommand(calculation);*/
        }

        private void m_rbIntegers_CheckedChanged(object sender, EventArgs e)
        {
            int x = m_tbNumber1.Text.ParseInt();
            int y = m_tbNumber2.Text.ParseInt();

            calculation = new Invoker(x, y);

            addCommand = new AddCommand(calculation);
            subCommand = new SubtractCommand(calculation);
            multCommand = new MultiplicationCommand(calculation);
            divCommand = new DivideCommand(calculation);
        }

        private void m_rbFloats_CheckedChanged(object sender, EventArgs e)
        {
            double doubleResult = doubVal;
        }

        #region Click Events For Commands
        private void m_btnAdd_Click(object sender, EventArgs e)
        {
            command = addCommand;
        }

        private void m_btnSubtract_Click(object sender, EventArgs e)
        {
            command = subCommand;
        }

        private void Multiply_Click(object sender, EventArgs e)
        {
            command = multCommand;
        }

        private void m_tbDivide_Click(object sender, EventArgs e)
        {
            command = divCommand;
        }
        #endregion

        private void m_btnDoCalculation_Click(object sender, EventArgs e)
        {
            m_tbFinalNumber.Text = command.Execute().ToString();
        }
  
    }
}
