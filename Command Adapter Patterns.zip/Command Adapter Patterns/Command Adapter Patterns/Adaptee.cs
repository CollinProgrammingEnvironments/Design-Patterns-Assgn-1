﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public class Adaptee
    {
        
        public double ChangetoDouble()
        {
            double doubleResult = 0;
            return doubleResult;
        }
    }
}
