﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public class Adapter : Target
    {
        protected Receiver doubleValue = null;
        
        public double GetDoubleValues()
        {
            Adaptee adaptee = new Adaptee();

            double doubVal = doubleValue.GetResult();
            return doubVal;
        }
    }
}
