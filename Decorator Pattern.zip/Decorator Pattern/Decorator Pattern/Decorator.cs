﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator_Pattern
{
    public class Decorator : Component
    {
        protected Component _comp;

        public Decorator(Component comp)
        {
            this._comp = comp;
        }

        public string displayPizza()
        {
            return _comp.displayPizza();
        }

        public string totalPrice(double crustPrice, double toppingPrice)
        {
            double totalprice = crustPrice + toppingPrice;
            string priceString = totalprice.ToString();
            return "The price of your newly created pizza is: $" + priceString;
        }
    }
}
