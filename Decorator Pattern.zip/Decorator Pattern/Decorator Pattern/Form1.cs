﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decorator_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region Variable Initializations
        double BaconPrice = 4.09;
        double HamPrice = 4.19;
        double SausagePrice = 5.00;

        double GreenPeppersPrice = 2.50;
        double BananaPeppersPrice = 2.50;
        double PineapplePrice = 3.00;
        double GreenOlivesPrice = 3.09;
        double GarlicPrice = 2.40;
        double MushroomsPrice = 4.00;

        double ThinCrustPrice = 6.00;
        double ThickCrustPrice = 5.50;
        double FlatbreadPrice = 6.50;
        double FocacciaPrice = 7.30;

        double meatPrice;
        double veggiePt1Price;
        double veggiePt2Price;
        double crustPrice;
        #endregion

        List<string> Toppings = new List<string>() 
        {
            "", "", "", ""
        };

        #region Create Pizza event
        private void m_btnCreatePizza_Click(object sender, EventArgs e)
        {
            string meatTopping;
            string veggiePt1Topping;
            string veggiePt2Topping;
            string crustType;

            double totalToppingPrice;
          
            if (m_rbBacon.Checked == true)  //meat topping set up
            {
                meatTopping = m_rbBacon.Text;
                Toppings[0] = meatTopping;
                meatPrice = BaconPrice;
            }
            else if (m_rbHam.Checked == true)
            {
                meatTopping = m_rbHam.Text;
                meatTopping = Toppings[0];
                meatPrice = HamPrice;
            }
            else if (m_rbSausage.Checked == true)
            {
                meatTopping = m_rbSausage.Text;
                Toppings[0] = meatTopping;
                meatPrice = SausagePrice;
            }

            if (m_rbMushrooms.Checked == true)   //veggies group 1 set up
            {
                veggiePt1Topping = m_rbMushrooms.Text;
                Toppings[1] = veggiePt1Topping;
                veggiePt1Price = MushroomsPrice;
            }
            else if (m_rbGarlic.Checked == true)
            {
                veggiePt1Topping = m_rbMushrooms.Text;
                Toppings[1] = veggiePt1Topping;
                veggiePt1Price = GarlicPrice;
            }
            else if (m_rbPineapple.Checked == true)
            {
                veggiePt1Topping = m_rbPineapple.Text;
                Toppings[1] = veggiePt1Topping;
                veggiePt1Price = PineapplePrice;
            }

            if (m_rbGreenOlives.Checked == true)    //veggies group 2 set up
            {
                veggiePt2Topping = m_rbGreenOlives.Text;
                Toppings[2] = veggiePt2Topping;
                veggiePt2Price = GreenOlivesPrice;
            }
            else if (m_rbGreenPeppers.Checked == true)
            {
                veggiePt2Topping = m_rbGreenPeppers.Text;
                Toppings[2] = veggiePt2Topping;
                veggiePt2Price = GreenPeppersPrice;
            }
            else if (m_rbBananaPeppers.Checked == true)
            {
                veggiePt2Topping = m_rbBananaPeppers.Text;
                Toppings[2] = veggiePt2Topping;
                veggiePt2Price = BananaPeppersPrice;
            }

            if (m_rbThinCrust.Checked == true)    //crust type set up
            {
                crustType = m_rbThinCrust.Text;
                Toppings[3] = crustType;
                crustPrice = ThinCrustPrice;
            }
            else if (m_rbThickCrust.Checked == true)
            {
                crustType = m_rbThickCrust.Text;
                Toppings[3] = crustType;
                crustPrice = ThickCrustPrice;
            }
            else if (m_rbFlatbread.Checked == true)
            {
                crustType = m_rbFlatbread.Text;
                Toppings[3] = crustType;
                crustPrice = FlatbreadPrice;
            }
            else if (m_rbFocaccia.Checked == true)
            {
                crustType = m_rbFocaccia.Text;
                Toppings[3] = crustType;
                crustPrice = FocacciaPrice;
            }

            totalToppingPrice = meatPrice + veggiePt1Price + veggiePt2Price;

            ConcreteComponent conccomp = new ConcreteComponent(Toppings[3], Toppings[0], Toppings[1], Toppings[2]);
            ConcreteDecorator concdec = new ConcreteDecorator(conccomp);

            if (!m_rbBacon.Checked && !m_rbHam.Checked && !m_rbSausage.Checked && !m_rbGreenOlives.Checked && !m_rbGreenPeppers.Checked &&
                !m_rbGarlic.Checked && !m_rbBananaPeppers.Checked && !m_rbMushrooms.Checked && !m_rbPineapple.Checked &&
                !m_rbThinCrust.Checked && !m_rbThickCrust.Checked && !m_rbFlatbread.Checked && !m_rbFocaccia.Checked)
            {
                MessageBox.Show("Please select your toppings and crust type!");
            }
            else
            {
                m_tbDisplayPizza.Text += conccomp.displayPizza() + System.Environment.NewLine;
                m_tbDisplayPizza.Text += concdec.totalPrice(crustPrice, totalToppingPrice);
                m_tbDisplayPizza.Text += System.Environment.NewLine + System.Environment.NewLine;
            }
        }
        #endregion
    }
}
