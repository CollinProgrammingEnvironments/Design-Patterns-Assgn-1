﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator_Pattern
{
    public class ConcreteComponent : Component
    {
        public string _crustType;
        public string _topping1;
        public string _topping2;
        public string _topping3;

        public ConcreteComponent(string crustType, string Topping1, string Topping2, string Topping3)
        {
            this._crustType = crustType;
            this._topping1 = Topping1;
            this._topping2 = Topping2;
            this._topping3 = Topping3;

            if (_topping1 != null)
            {
                _topping1 = _topping1 + " ";
            }
            if (_topping2 != null)
            {
                _topping2 = _topping2 + " ";
            }
            if (_topping3 != null)
            {
                _topping3 = _topping3 + " ";
            }
        }

        public string displayPizza()
        {
            return "You have selected to consume a " + _topping1 + _topping2 + _topping3 + "pizza with " + _crustType + ".";
        }
    }
}
