﻿namespace Decorator_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.m_gbToppings = new System.Windows.Forms.GroupBox();
            this.m_gbVeggiesPt2 = new System.Windows.Forms.GroupBox();
            this.m_rbGreenOlives = new System.Windows.Forms.RadioButton();
            this.m_rbBananaPeppers = new System.Windows.Forms.RadioButton();
            this.m_rbGreenPeppers = new System.Windows.Forms.RadioButton();
            this.m_gbVeggiesPt1 = new System.Windows.Forms.GroupBox();
            this.m_rbPineapple = new System.Windows.Forms.RadioButton();
            this.m_rbGarlic = new System.Windows.Forms.RadioButton();
            this.m_rbMushrooms = new System.Windows.Forms.RadioButton();
            this.m_gbMeatToppings = new System.Windows.Forms.GroupBox();
            this.m_rbSausage = new System.Windows.Forms.RadioButton();
            this.m_rbHam = new System.Windows.Forms.RadioButton();
            this.m_rbBacon = new System.Windows.Forms.RadioButton();
            this.m_gbBreadCrust = new System.Windows.Forms.GroupBox();
            this.m_rbFocaccia = new System.Windows.Forms.RadioButton();
            this.m_rbThickCrust = new System.Windows.Forms.RadioButton();
            this.m_rbFlatbread = new System.Windows.Forms.RadioButton();
            this.m_rbThinCrust = new System.Windows.Forms.RadioButton();
            this.m_btnCreatePizza = new System.Windows.Forms.Button();
            this.m_tbDisplayPizza = new System.Windows.Forms.TextBox();
            this.m_gbToppings.SuspendLayout();
            this.m_gbVeggiesPt2.SuspendLayout();
            this.m_gbVeggiesPt1.SuspendLayout();
            this.m_gbMeatToppings.SuspendLayout();
            this.m_gbBreadCrust.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_gbToppings
            // 
            this.m_gbToppings.Controls.Add(this.m_gbVeggiesPt2);
            this.m_gbToppings.Controls.Add(this.m_gbVeggiesPt1);
            this.m_gbToppings.Controls.Add(this.m_gbMeatToppings);
            this.m_gbToppings.Location = new System.Drawing.Point(238, 12);
            this.m_gbToppings.Name = "m_gbToppings";
            this.m_gbToppings.Size = new System.Drawing.Size(207, 217);
            this.m_gbToppings.TabIndex = 0;
            this.m_gbToppings.TabStop = false;
            this.m_gbToppings.Text = "Pick 3 Toppings";
            // 
            // m_gbVeggiesPt2
            // 
            this.m_gbVeggiesPt2.Controls.Add(this.m_rbGreenOlives);
            this.m_gbVeggiesPt2.Controls.Add(this.m_rbBananaPeppers);
            this.m_gbVeggiesPt2.Controls.Add(this.m_rbGreenPeppers);
            this.m_gbVeggiesPt2.Location = new System.Drawing.Point(6, 141);
            this.m_gbVeggiesPt2.Name = "m_gbVeggiesPt2";
            this.m_gbVeggiesPt2.Size = new System.Drawing.Size(201, 64);
            this.m_gbVeggiesPt2.TabIndex = 5;
            this.m_gbVeggiesPt2.TabStop = false;
            this.m_gbVeggiesPt2.Text = "Vegetable Toppings Group 2";
            // 
            // m_rbGreenOlives
            // 
            this.m_rbGreenOlives.AutoSize = true;
            this.m_rbGreenOlives.Location = new System.Drawing.Point(108, 19);
            this.m_rbGreenOlives.Name = "m_rbGreenOlives";
            this.m_rbGreenOlives.Size = new System.Drawing.Size(86, 17);
            this.m_rbGreenOlives.TabIndex = 2;
            this.m_rbGreenOlives.Text = "Green Olives";
            this.m_rbGreenOlives.UseVisualStyleBackColor = true;
            // 
            // m_rbBananaPeppers
            // 
            this.m_rbBananaPeppers.AutoSize = true;
            this.m_rbBananaPeppers.Location = new System.Drawing.Point(54, 41);
            this.m_rbBananaPeppers.Name = "m_rbBananaPeppers";
            this.m_rbBananaPeppers.Size = new System.Drawing.Size(104, 17);
            this.m_rbBananaPeppers.TabIndex = 1;
            this.m_rbBananaPeppers.Text = "Banana Peppers";
            this.m_rbBananaPeppers.UseVisualStyleBackColor = true;
            // 
            // m_rbGreenPeppers
            // 
            this.m_rbGreenPeppers.AutoSize = true;
            this.m_rbGreenPeppers.Location = new System.Drawing.Point(6, 19);
            this.m_rbGreenPeppers.Name = "m_rbGreenPeppers";
            this.m_rbGreenPeppers.Size = new System.Drawing.Size(96, 17);
            this.m_rbGreenPeppers.TabIndex = 0;
            this.m_rbGreenPeppers.Text = "Green Peppers";
            this.m_rbGreenPeppers.UseVisualStyleBackColor = true;
            // 
            // m_gbVeggiesPt1
            // 
            this.m_gbVeggiesPt1.Controls.Add(this.m_rbPineapple);
            this.m_gbVeggiesPt1.Controls.Add(this.m_rbGarlic);
            this.m_gbVeggiesPt1.Controls.Add(this.m_rbMushrooms);
            this.m_gbVeggiesPt1.Location = new System.Drawing.Point(8, 71);
            this.m_gbVeggiesPt1.Name = "m_gbVeggiesPt1";
            this.m_gbVeggiesPt1.Size = new System.Drawing.Size(193, 64);
            this.m_gbVeggiesPt1.TabIndex = 4;
            this.m_gbVeggiesPt1.TabStop = false;
            this.m_gbVeggiesPt1.Text = "Vegetable Toppings Group 1";
            // 
            // m_rbPineapple
            // 
            this.m_rbPineapple.AutoSize = true;
            this.m_rbPineapple.Location = new System.Drawing.Point(63, 41);
            this.m_rbPineapple.Name = "m_rbPineapple";
            this.m_rbPineapple.Size = new System.Drawing.Size(72, 17);
            this.m_rbPineapple.TabIndex = 8;
            this.m_rbPineapple.Text = "Pineapple";
            this.m_rbPineapple.UseVisualStyleBackColor = true;
            // 
            // m_rbGarlic
            // 
            this.m_rbGarlic.AutoSize = true;
            this.m_rbGarlic.Location = new System.Drawing.Point(127, 19);
            this.m_rbGarlic.Name = "m_rbGarlic";
            this.m_rbGarlic.Size = new System.Drawing.Size(52, 17);
            this.m_rbGarlic.TabIndex = 7;
            this.m_rbGarlic.Text = "Garlic";
            this.m_rbGarlic.UseVisualStyleBackColor = true;
            // 
            // m_rbMushrooms
            // 
            this.m_rbMushrooms.AutoSize = true;
            this.m_rbMushrooms.Location = new System.Drawing.Point(6, 19);
            this.m_rbMushrooms.Name = "m_rbMushrooms";
            this.m_rbMushrooms.Size = new System.Drawing.Size(79, 17);
            this.m_rbMushrooms.TabIndex = 6;
            this.m_rbMushrooms.Text = "Mushrooms";
            this.m_rbMushrooms.UseVisualStyleBackColor = true;
            // 
            // m_gbMeatToppings
            // 
            this.m_gbMeatToppings.Controls.Add(this.m_rbSausage);
            this.m_gbMeatToppings.Controls.Add(this.m_rbHam);
            this.m_gbMeatToppings.Controls.Add(this.m_rbBacon);
            this.m_gbMeatToppings.Location = new System.Drawing.Point(6, 19);
            this.m_gbMeatToppings.Name = "m_gbMeatToppings";
            this.m_gbMeatToppings.Size = new System.Drawing.Size(195, 46);
            this.m_gbMeatToppings.TabIndex = 3;
            this.m_gbMeatToppings.TabStop = false;
            this.m_gbMeatToppings.Text = "Meat Toppings";
            // 
            // m_rbSausage
            // 
            this.m_rbSausage.AutoSize = true;
            this.m_rbSausage.Location = new System.Drawing.Point(118, 19);
            this.m_rbSausage.Name = "m_rbSausage";
            this.m_rbSausage.Size = new System.Drawing.Size(67, 17);
            this.m_rbSausage.TabIndex = 5;
            this.m_rbSausage.Text = "Sausage";
            this.m_rbSausage.UseVisualStyleBackColor = true;
            // 
            // m_rbHam
            // 
            this.m_rbHam.AutoSize = true;
            this.m_rbHam.Location = new System.Drawing.Point(65, 19);
            this.m_rbHam.Name = "m_rbHam";
            this.m_rbHam.Size = new System.Drawing.Size(47, 17);
            this.m_rbHam.TabIndex = 4;
            this.m_rbHam.Text = "Ham";
            this.m_rbHam.UseVisualStyleBackColor = true;
            // 
            // m_rbBacon
            // 
            this.m_rbBacon.AutoSize = true;
            this.m_rbBacon.Location = new System.Drawing.Point(8, 19);
            this.m_rbBacon.Name = "m_rbBacon";
            this.m_rbBacon.Size = new System.Drawing.Size(56, 17);
            this.m_rbBacon.TabIndex = 3;
            this.m_rbBacon.Text = "Bacon";
            this.m_rbBacon.UseVisualStyleBackColor = true;
            // 
            // m_gbBreadCrust
            // 
            this.m_gbBreadCrust.Controls.Add(this.m_rbFocaccia);
            this.m_gbBreadCrust.Controls.Add(this.m_rbThickCrust);
            this.m_gbBreadCrust.Controls.Add(this.m_rbFlatbread);
            this.m_gbBreadCrust.Controls.Add(this.m_rbThinCrust);
            this.m_gbBreadCrust.Location = new System.Drawing.Point(238, 252);
            this.m_gbBreadCrust.Name = "m_gbBreadCrust";
            this.m_gbBreadCrust.Size = new System.Drawing.Size(207, 70);
            this.m_gbBreadCrust.TabIndex = 1;
            this.m_gbBreadCrust.TabStop = false;
            this.m_gbBreadCrust.Text = "Pick A Type Of Crust";
            // 
            // m_rbFocaccia
            // 
            this.m_rbFocaccia.AutoSize = true;
            this.m_rbFocaccia.Location = new System.Drawing.Point(118, 42);
            this.m_rbFocaccia.Name = "m_rbFocaccia";
            this.m_rbFocaccia.Size = new System.Drawing.Size(69, 17);
            this.m_rbFocaccia.TabIndex = 3;
            this.m_rbFocaccia.Text = "Focaccia";
            this.m_rbFocaccia.UseVisualStyleBackColor = true;
            // 
            // m_rbThickCrust
            // 
            this.m_rbThickCrust.AutoSize = true;
            this.m_rbThickCrust.Location = new System.Drawing.Point(6, 42);
            this.m_rbThickCrust.Name = "m_rbThickCrust";
            this.m_rbThickCrust.Size = new System.Drawing.Size(79, 17);
            this.m_rbThickCrust.TabIndex = 2;
            this.m_rbThickCrust.Text = "Thick Crust";
            this.m_rbThickCrust.UseVisualStyleBackColor = true;
            // 
            // m_rbFlatbread
            // 
            this.m_rbFlatbread.AutoSize = true;
            this.m_rbFlatbread.Location = new System.Drawing.Point(118, 19);
            this.m_rbFlatbread.Name = "m_rbFlatbread";
            this.m_rbFlatbread.Size = new System.Drawing.Size(69, 17);
            this.m_rbFlatbread.TabIndex = 1;
            this.m_rbFlatbread.Text = "Flatbread";
            this.m_rbFlatbread.UseVisualStyleBackColor = true;
            // 
            // m_rbThinCrust
            // 
            this.m_rbThinCrust.AutoSize = true;
            this.m_rbThinCrust.Location = new System.Drawing.Point(6, 19);
            this.m_rbThinCrust.Name = "m_rbThinCrust";
            this.m_rbThinCrust.Size = new System.Drawing.Size(73, 17);
            this.m_rbThinCrust.TabIndex = 0;
            this.m_rbThinCrust.Text = "Thin Crust";
            this.m_rbThinCrust.UseVisualStyleBackColor = true;
            // 
            // m_btnCreatePizza
            // 
            this.m_btnCreatePizza.Location = new System.Drawing.Point(61, 271);
            this.m_btnCreatePizza.Name = "m_btnCreatePizza";
            this.m_btnCreatePizza.Size = new System.Drawing.Size(77, 31);
            this.m_btnCreatePizza.TabIndex = 3;
            this.m_btnCreatePizza.Text = "Create Pizza";
            this.m_btnCreatePizza.UseVisualStyleBackColor = true;
            this.m_btnCreatePizza.Click += new System.EventHandler(this.m_btnCreatePizza_Click);
            // 
            // m_tbDisplayPizza
            // 
            this.m_tbDisplayPizza.Location = new System.Drawing.Point(12, 12);
            this.m_tbDisplayPizza.Multiline = true;
            this.m_tbDisplayPizza.Name = "m_tbDisplayPizza";
            this.m_tbDisplayPizza.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.m_tbDisplayPizza.Size = new System.Drawing.Size(220, 217);
            this.m_tbDisplayPizza.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(455, 367);
            this.Controls.Add(this.m_tbDisplayPizza);
            this.Controls.Add(this.m_btnCreatePizza);
            this.Controls.Add(this.m_gbBreadCrust);
            this.Controls.Add(this.m_gbToppings);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pizza Maker";
            this.m_gbToppings.ResumeLayout(false);
            this.m_gbVeggiesPt2.ResumeLayout(false);
            this.m_gbVeggiesPt2.PerformLayout();
            this.m_gbVeggiesPt1.ResumeLayout(false);
            this.m_gbVeggiesPt1.PerformLayout();
            this.m_gbMeatToppings.ResumeLayout(false);
            this.m_gbMeatToppings.PerformLayout();
            this.m_gbBreadCrust.ResumeLayout(false);
            this.m_gbBreadCrust.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox m_gbToppings;
        private System.Windows.Forms.GroupBox m_gbVeggiesPt1;
        private System.Windows.Forms.GroupBox m_gbMeatToppings;
        private System.Windows.Forms.GroupBox m_gbBreadCrust;
        private System.Windows.Forms.RadioButton m_rbThinCrust;
        private System.Windows.Forms.RadioButton m_rbFlatbread;
        private System.Windows.Forms.RadioButton m_rbFocaccia;
        private System.Windows.Forms.RadioButton m_rbThickCrust;
        private System.Windows.Forms.Button m_btnCreatePizza;
        private System.Windows.Forms.RadioButton m_rbBacon;
        private System.Windows.Forms.RadioButton m_rbSausage;
        private System.Windows.Forms.RadioButton m_rbHam;
        private System.Windows.Forms.GroupBox m_gbVeggiesPt2;
        private System.Windows.Forms.RadioButton m_rbGreenOlives;
        private System.Windows.Forms.RadioButton m_rbBananaPeppers;
        private System.Windows.Forms.RadioButton m_rbGreenPeppers;
        private System.Windows.Forms.RadioButton m_rbPineapple;
        private System.Windows.Forms.RadioButton m_rbGarlic;
        private System.Windows.Forms.RadioButton m_rbMushrooms;
        private System.Windows.Forms.TextBox m_tbDisplayPizza;
    }
}

