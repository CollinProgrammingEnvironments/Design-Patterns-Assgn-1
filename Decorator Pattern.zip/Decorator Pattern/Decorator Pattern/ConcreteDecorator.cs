﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator_Pattern
{
    public class ConcreteDecorator : Decorator
    {
        public ConcreteDecorator(Component _comp)
            : base(_comp)
        {

        }
        
        public string displayPizza()
        {
            return _comp.displayPizza();
        }
        public string totalPrice(double crustPrice, double toppingPrice)
        {
            double totalprice = crustPrice + toppingPrice;
            string priceString = totalprice.ToString();
            return "The price of your newly created pizza is: $" + priceString;
        }
    }
}
