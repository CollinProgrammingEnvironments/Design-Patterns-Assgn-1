﻿namespace Bridge_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_rbGarageRock = new System.Windows.Forms.RadioButton();
            this.m_rbClassicRock = new System.Windows.Forms.RadioButton();
            this.m_rbPunkRock = new System.Windows.Forms.RadioButton();
            this.m_gbGenres = new System.Windows.Forms.GroupBox();
            this.m_tbNowPlaying = new System.Windows.Forms.TextBox();
            this.m_btnPlay = new System.Windows.Forms.Button();
            this.m_gbGenres.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_rbGarageRock
            // 
            this.m_rbGarageRock.AutoSize = true;
            this.m_rbGarageRock.Location = new System.Drawing.Point(6, 19);
            this.m_rbGarageRock.Name = "m_rbGarageRock";
            this.m_rbGarageRock.Size = new System.Drawing.Size(89, 17);
            this.m_rbGarageRock.TabIndex = 0;
            this.m_rbGarageRock.Text = "Garage Rock";
            this.m_rbGarageRock.UseVisualStyleBackColor = true;
            // 
            // m_rbClassicRock
            // 
            this.m_rbClassicRock.AutoSize = true;
            this.m_rbClassicRock.Location = new System.Drawing.Point(6, 42);
            this.m_rbClassicRock.Name = "m_rbClassicRock";
            this.m_rbClassicRock.Size = new System.Drawing.Size(87, 17);
            this.m_rbClassicRock.TabIndex = 1;
            this.m_rbClassicRock.Text = "Classic Rock";
            this.m_rbClassicRock.UseVisualStyleBackColor = true;
            // 
            // m_rbPunkRock
            // 
            this.m_rbPunkRock.AutoSize = true;
            this.m_rbPunkRock.Location = new System.Drawing.Point(6, 65);
            this.m_rbPunkRock.Name = "m_rbPunkRock";
            this.m_rbPunkRock.Size = new System.Drawing.Size(79, 17);
            this.m_rbPunkRock.TabIndex = 2;
            this.m_rbPunkRock.Text = "Punk Rock";
            this.m_rbPunkRock.UseVisualStyleBackColor = true;
            // 
            // m_gbGenres
            // 
            this.m_gbGenres.Controls.Add(this.m_rbPunkRock);
            this.m_gbGenres.Controls.Add(this.m_rbClassicRock);
            this.m_gbGenres.Controls.Add(this.m_rbGarageRock);
            this.m_gbGenres.Location = new System.Drawing.Point(87, 12);
            this.m_gbGenres.Name = "m_gbGenres";
            this.m_gbGenres.Size = new System.Drawing.Size(105, 91);
            this.m_gbGenres.TabIndex = 3;
            this.m_gbGenres.TabStop = false;
            this.m_gbGenres.Text = "Rock Genres";
            // 
            // m_tbNowPlaying
            // 
            this.m_tbNowPlaying.BackColor = System.Drawing.SystemColors.ControlDark;
            this.m_tbNowPlaying.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_tbNowPlaying.Location = new System.Drawing.Point(8, 154);
            this.m_tbNowPlaying.Multiline = true;
            this.m_tbNowPlaying.Name = "m_tbNowPlaying";
            this.m_tbNowPlaying.Size = new System.Drawing.Size(264, 95);
            this.m_tbNowPlaying.TabIndex = 4;
            this.m_tbNowPlaying.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_btnPlay
            // 
            this.m_btnPlay.BackColor = System.Drawing.SystemColors.MenuBar;
            this.m_btnPlay.Cursor = System.Windows.Forms.Cursors.Default;
            this.m_btnPlay.Location = new System.Drawing.Point(98, 122);
            this.m_btnPlay.Name = "m_btnPlay";
            this.m_btnPlay.Size = new System.Drawing.Size(81, 26);
            this.m_btnPlay.TabIndex = 5;
            this.m_btnPlay.Text = "Play";
            this.m_btnPlay.UseVisualStyleBackColor = false;
            this.m_btnPlay.Click += new System.EventHandler(this.m_btnPlay_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.m_btnPlay);
            this.Controls.Add(this.m_tbNowPlaying);
            this.Controls.Add(this.m_gbGenres);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Music Player Simulation!";
            this.m_gbGenres.ResumeLayout(false);
            this.m_gbGenres.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton m_rbGarageRock;
        private System.Windows.Forms.RadioButton m_rbClassicRock;
        private System.Windows.Forms.RadioButton m_rbPunkRock;
        private System.Windows.Forms.GroupBox m_gbGenres;
        private System.Windows.Forms.TextBox m_tbNowPlaying;
        private System.Windows.Forms.Button m_btnPlay;
    }
}

