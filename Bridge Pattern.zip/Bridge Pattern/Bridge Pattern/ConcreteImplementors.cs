﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge_Pattern
{
    #region GarageRock class

    public class GarageRock : Implementor   //Concrete Implementor class
    {
        static Random rand = new Random();
        
        const string INTRO = "Genre: ";
        const string PLAY = "Now playing: ";

        public List<string> _musicAlbum = new List<string>();
        
        public GarageRock()
        {
            _musicAlbum.Add("Superfuzz Bigmuff by Mudhoney");
            _musicAlbum.Add("Twins by Ty Segall");
            _musicAlbum.Add("Here Be Thee Gories by The Gories");
            _musicAlbum.Add("The Traditional Fools by The Traditional Fools");
            _musicAlbum.Add("Help by Thee Oh Sees");
            _musicAlbum.Add("Still Life of Citrus and Slime by CFM");
            _musicAlbum.Add("Moonhearts by Charlie and the Moonhearts");
            _musicAlbum.Add("Bass Drum of Death by Bass Drum of Death");
        }

        public string randomString()
        {
            int Index = rand.Next(_musicAlbum.Count);
            string randomString = _musicAlbum[Index];
            return randomString;
        }
        
        string Implementor.GetMusicGenre()
        {
            return INTRO + "Garage Rock";
        }
        string Implementor.PlayMusic()
        {
            return PLAY + randomString();
        }       
    }

    #endregion

    #region ClassicRock class

    public class ClassicRock : Implementor //Concrete Implementor class
    {
        static Random rand = new Random();
        
        const string INTRO = "Genre: ";
        const string PLAY = "Now playing: ";

        public List<string> _musicAlbum = new List<string>();
        
        public ClassicRock()
        {
            _musicAlbum.Add("Led Zeppelin II by Led Zeppelin");
            _musicAlbum.Add("Pipers At The Gates Of Dawn by Pink Floyd");
            _musicAlbum.Add("Electric Ladyland by Jimi Hendrix");
            _musicAlbum.Add("Paranoid by Black Sabbath");
            _musicAlbum.Add("Cheap Thrills by Big Brother & The Holding Company");
            _musicAlbum.Add("Sgt. Pepper's Lonely Hearts Club Band by The Beatles");
            _musicAlbum.Add("Waiting For The Sun by The Doors");
            _musicAlbum.Add("Part One by The West Coast Pop Art Experimental Band");
        }

        public string randomString()
        {
            int Index = rand.Next(_musicAlbum.Count);
            string randomString = _musicAlbum[Index];
            return randomString;
        }
        
        string Implementor.GetMusicGenre()
        {
            return INTRO + "Classic Rock";
        }
        string Implementor.PlayMusic()
        {
            return PLAY + randomString();
        }
    }

    #endregion

    #region PunkRock class

    public class PunkRock : Implementor //Concrete Implementor class
    {
        static Random rand = new Random();
        
        const string INTRO = "Genre: ";
        const string PLAY = "Now playing: ";

        public List<string> _musicAlbum = new List<string>();
        
        public PunkRock()
        {
            _musicAlbum.Add("GØGGS by GØGGS");
            _musicAlbum.Add("Dirty by Sonic Youth");
            _musicAlbum.Add("Bleach by Nirvana");
            _musicAlbum.Add("Nevermind the Bollocks, Here's the Sex Pistols by Sex Pistols");
            _musicAlbum.Add("Milo Goes To College by Descendents");
            _musicAlbum.Add("Rocket To Russia by The Ramones");
            _musicAlbum.Add("Damaged by Black Flag");
            _musicAlbum.Add("Living in Darkness by Agent Orange");
        }

        public string randomString()
        {
            int Index = rand.Next(_musicAlbum.Count);
            string randomString = _musicAlbum[Index];
            return randomString;
        }
        
        string Implementor.GetMusicGenre()
        {
            return INTRO + "Punk Rock";
        }
        string Implementor.PlayMusic()
        {
            return PLAY + randomString();
        }
    }

    #endregion 
}
