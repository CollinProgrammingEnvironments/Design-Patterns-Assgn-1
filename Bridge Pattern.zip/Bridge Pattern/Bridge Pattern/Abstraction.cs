﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge_Pattern
{
    public abstract class Abstraction  //Abstraction class
    {
        protected Implementor imp;
  
        public Implementor implementor
        {
            get { return imp; }
            set { imp = value; }
        }

        public virtual string getAllInfo()
        {
            string info = imp.GetMusicGenre() + System.Environment.NewLine + imp.PlayMusic();
            return info;
        }
    }
}
