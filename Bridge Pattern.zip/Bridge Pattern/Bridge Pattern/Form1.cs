﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bridge_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Abstraction abstraction = new RefinedAbstraction();

        private void m_btnPlay_Click(object sender, EventArgs e)
        {
            if (m_rbGarageRock.Checked)
            {
                abstraction.implementor = new GarageRock();
                m_tbNowPlaying.Text = abstraction.getAllInfo();
            }
            else if (m_rbClassicRock.Checked)
            {
                abstraction.implementor = new ClassicRock();
                m_tbNowPlaying.Text = abstraction.getAllInfo();
            }
            else if (m_rbPunkRock.Checked)
            {
                abstraction.implementor = new PunkRock();
                m_tbNowPlaying.Text = abstraction.getAllInfo();
            }
        }
    }
}
