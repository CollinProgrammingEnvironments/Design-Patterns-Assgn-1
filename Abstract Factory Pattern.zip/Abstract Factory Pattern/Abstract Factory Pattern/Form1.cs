﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abstract_Factory_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void m_btnMustang_Click(object sender, EventArgs e)
        {
            AbstractFactorySolid guitarFactory = new ConcreteFactorySolid();
            string factoryString = guitarFactory.createSolidBody1().ToString();
            
            m_tbFactoryBox.Text = factoryString;
        }

        private void m_btnStratocaster_Click(object sender, EventArgs e)
        {
            AbstractFactorySolid guitarFactory = new ConcreteFactorySolid();
            string factoryString = guitarFactory.createSolidBody2().ToString();

            m_tbFactoryBox.Text = factoryString;
        }

        private void m_btnES335_Click(object sender, EventArgs e)
        {
            AbstractFactoryHollow guitarFactory = new ConcreteFactoryHollow();
            string factoryString = guitarFactory.createHollowBody1().ToString();

            m_tbFactoryBox.Text = factoryString;
        }

        private void m_btnLesPaul_Click(object sender, EventArgs e)
        {
            AbstractFactorySolid guitarFactory = new ConcreteFactorySolid();
            string factoryString = guitarFactory.createSolidBody3().ToString();

            m_tbFactoryBox.Text = factoryString;
        }

        private void m_btnAF55_Click(object sender, EventArgs e)
        {
            AbstractFactoryHollow guitarFactory = new ConcreteFactoryHollow();
            string factoryString = guitarFactory.createHollowBody2().ToString();

            m_tbFactoryBox.Text = factoryString;
        }
    }
}
