﻿namespace Abstract_Factory_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_btnMustang = new System.Windows.Forms.Button();
            this.m_btnStratocaster = new System.Windows.Forms.Button();
            this.m_btnES335 = new System.Windows.Forms.Button();
            this.m_btnLesPaul = new System.Windows.Forms.Button();
            this.m_btnAF55 = new System.Windows.Forms.Button();
            this.m_lblGuitars = new System.Windows.Forms.Label();
            this.m_tbFactoryBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_btnMustang
            // 
            this.m_btnMustang.Location = new System.Drawing.Point(35, 69);
            this.m_btnMustang.Name = "m_btnMustang";
            this.m_btnMustang.Size = new System.Drawing.Size(100, 25);
            this.m_btnMustang.TabIndex = 1;
            this.m_btnMustang.Text = "Fender Mustang";
            this.m_btnMustang.UseVisualStyleBackColor = true;
            this.m_btnMustang.Click += new System.EventHandler(this.m_btnMustang_Click);
            // 
            // m_btnStratocaster
            // 
            this.m_btnStratocaster.Location = new System.Drawing.Point(35, 100);
            this.m_btnStratocaster.Name = "m_btnStratocaster";
            this.m_btnStratocaster.Size = new System.Drawing.Size(100, 39);
            this.m_btnStratocaster.TabIndex = 2;
            this.m_btnStratocaster.Text = "Fender Stratocaster";
            this.m_btnStratocaster.UseVisualStyleBackColor = true;
            this.m_btnStratocaster.Click += new System.EventHandler(this.m_btnStratocaster_Click);
            // 
            // m_btnES335
            // 
            this.m_btnES335.Location = new System.Drawing.Point(35, 145);
            this.m_btnES335.Name = "m_btnES335";
            this.m_btnES335.Size = new System.Drawing.Size(100, 27);
            this.m_btnES335.TabIndex = 3;
            this.m_btnES335.Text = "Gibson ES-335";
            this.m_btnES335.UseVisualStyleBackColor = true;
            this.m_btnES335.Click += new System.EventHandler(this.m_btnES335_Click);
            // 
            // m_btnLesPaul
            // 
            this.m_btnLesPaul.Location = new System.Drawing.Point(35, 178);
            this.m_btnLesPaul.Name = "m_btnLesPaul";
            this.m_btnLesPaul.Size = new System.Drawing.Size(100, 27);
            this.m_btnLesPaul.TabIndex = 4;
            this.m_btnLesPaul.Text = "Gibson Les Paul";
            this.m_btnLesPaul.UseVisualStyleBackColor = true;
            this.m_btnLesPaul.Click += new System.EventHandler(this.m_btnLesPaul_Click);
            // 
            // m_btnAF55
            // 
            this.m_btnAF55.Location = new System.Drawing.Point(35, 211);
            this.m_btnAF55.Name = "m_btnAF55";
            this.m_btnAF55.Size = new System.Drawing.Size(100, 23);
            this.m_btnAF55.TabIndex = 5;
            this.m_btnAF55.Text = "Ibanez AF55";
            this.m_btnAF55.UseVisualStyleBackColor = true;
            this.m_btnAF55.Click += new System.EventHandler(this.m_btnAF55_Click);
            // 
            // m_lblGuitars
            // 
            this.m_lblGuitars.AutoSize = true;
            this.m_lblGuitars.Location = new System.Drawing.Point(32, 53);
            this.m_lblGuitars.Name = "m_lblGuitars";
            this.m_lblGuitars.Size = new System.Drawing.Size(93, 13);
            this.m_lblGuitars.TabIndex = 6;
            this.m_lblGuitars.Text = "Guitars To Create:";
            // 
            // m_tbFactoryBox
            // 
            this.m_tbFactoryBox.Location = new System.Drawing.Point(158, 111);
            this.m_tbFactoryBox.Multiline = true;
            this.m_tbFactoryBox.Name = "m_tbFactoryBox";
            this.m_tbFactoryBox.Size = new System.Drawing.Size(157, 79);
            this.m_tbFactoryBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 323);
            this.Controls.Add(this.m_tbFactoryBox);
            this.Controls.Add(this.m_lblGuitars);
            this.Controls.Add(this.m_btnAF55);
            this.Controls.Add(this.m_btnLesPaul);
            this.Controls.Add(this.m_btnES335);
            this.Controls.Add(this.m_btnStratocaster);
            this.Controls.Add(this.m_btnMustang);
            this.Name = "Form1";
            this.Text = "Guitar Factory";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnMustang;
        private System.Windows.Forms.Button m_btnStratocaster;
        private System.Windows.Forms.Button m_btnES335;
        private System.Windows.Forms.Button m_btnLesPaul;
        private System.Windows.Forms.Button m_btnAF55;
        private System.Windows.Forms.Label m_lblGuitars;
        private System.Windows.Forms.TextBox m_tbFactoryBox;
    }
}

