﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory_Pattern
{
    public abstract class SolidBody   //Abstract product class (SolidBody)
    {
        private string Name;
        private string Weight;
        private string NeckWidth;
        private string BridgeType;
        private string BodyType;
    }  
    public class FenderMustang : SolidBody   //fender mustang class (product class)
    {
        public string Name = "Fender Mustang";
        public string Weight = "~6 lbs";
        public string NeckWidth = "Slim";
        public string BridgeType = "Tremolo";
        public string BodyType = "Solid";
        
        public override string ToString()
        {
            string FullDescription = "Guitar Produced:" + "\r\n" + "Name: " + Name + "\r\n" + "Weight: " + Weight + "\r\n" + "Neck Style: " + NeckWidth + "\r\n" + "Bridge Type: " + BridgeType + "\r\n" + "Body Type: " + BodyType;
            
            return FullDescription;
        }
    }
    public class FenderStratocaster : SolidBody  //fender stratocaster class (product class)
    {
        public string Name = "Fender Stratocaster";
        public string Weight = "~6-7 lbs";
        public string NeckWidth = "Slim";
        public string BridgeType = "Fixed or Tremolo";
        public string BodyType = "Solid";

        public override string ToString()
        {
            string FullDescription = "Guitar Produced:" + "\r\n" + "Name: " + Name + "\r\n" + "Weight: " + Weight + "\r\n" + "Neck Style: " + NeckWidth + "\r\n" + "Bridge Type: " + BridgeType + "\r\n" + "Body Type: " + BodyType + "\r\n";

            return FullDescription;        
        }
    }
    public class GibsonLesPaul : SolidBody    //gibson les paul class (product class)
    {
        public string Name = "Gibson Les Paul";
        public string Weight = "~ 11 lbs";
        public string NeckWidth = "Fat";
        public string BridgeType = "Fixed";
        public string BodyType = "Solid";

        public override string ToString()
        {
            string FullDescription = "Guitar Produced:" + "\r\n" + "Name: " + Name + "\r\n" + "Weight: " + Weight + "\r\n" + "Neck Style: " + NeckWidth + "\r\n" + "Bridge Type: " + BridgeType + "\r\n" + "Body Type: " + BodyType + "\r\n";

            return FullDescription;
        }
    }

    public abstract class HollowBody     //Abstract product interface (HollowBody)
    {
        private string Name;
        private string Weight;
        private string NeckWidth;
        private string BridgeType;
        private string BodyType;
    }
    public class GibsonES335 : HollowBody   //gibson es-335 class (product class)
    {
        public string Name = "Gibson ES-335";
        public string Weight = "~7 lbs";
        public string NeckWidth = "Fat";
        public string BridgeType = "Fixed or Floating";
        public string BodyType = "Hollow";

        public override string ToString()
        {
            string FullDescription = "Guitar Produced:" + "\r\n" + "Name: " + Name + "\r\n" + "Weight: " + Weight + "\r\n" + "Neck Style: " + NeckWidth + "\r\n" + "Bridge Type: " + BridgeType + "\r\n" + "Body Type: " + BodyType + "\r\n";

            return FullDescription;
        }
    }
    public class IbanezAF55 : HollowBody   //ibanez af55 class (product class)
    {
        public string Name = "Ibanez AF55";
        public string Weight = "~5-6 lbs";
        public string NeckWidth = "Fat";
        public string BridgeType = "Floating";
        public string BodyType = "Hollow";

        public override string ToString()
        {
            string FullDescription = "Guitar Produced:" + "\r\n" + "Name: " + Name + "\r\n" + "Weight: " + Weight + "\r\n" + "Neck Style: " + NeckWidth + "\r\n" + "Bridge Type: " + BridgeType + "\r\n" + "Body Type: " + BodyType + "\r\n";

            return FullDescription;
        }
    }
}
