﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Factory_Pattern
{
    public interface AbstractFactorySolid   //abstract factory class
    {
        SolidBody createSolidBody1();
        SolidBody createSolidBody2();
        SolidBody createSolidBody3();
    }

    public interface AbstractFactoryHollow
    {
        HollowBody createHollowBody1();
        HollowBody createHollowBody2();
    }

    public class ConcreteFactorySolid : AbstractFactorySolid   //concrete factory solid body guitars
    {
        public SolidBody createSolidBody1()
        {
            return new FenderMustang();
        }
        public SolidBody createSolidBody2()
        {
            return new FenderStratocaster();
        }
        public SolidBody createSolidBody3()
        {
            return new GibsonLesPaul();
        }
    }

    public class ConcreteFactoryHollow : AbstractFactoryHollow    //concrete factory hollow body guitars
    {
        public HollowBody createHollowBody1()
        {
            return new GibsonES335();
        }
        public HollowBody createHollowBody2()
        {
            return new IbanezAF55();
        }
    }
}
