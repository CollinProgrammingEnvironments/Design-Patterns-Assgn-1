﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public interface Target
    {
        int Request(double i);
    }
}
