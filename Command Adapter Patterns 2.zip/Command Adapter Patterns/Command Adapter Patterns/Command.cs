﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public abstract class Command
    {
        protected Receiver _receiver = null;

        public Command(Receiver receiver)
        {
            _receiver = receiver;
        }
        public abstract double Execute();
    }
}
