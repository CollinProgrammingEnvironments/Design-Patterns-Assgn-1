﻿namespace Command_Adapter_Patterns
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_tbFinalNumber = new System.Windows.Forms.TextBox();
            this.m_btnAdd = new System.Windows.Forms.Button();
            this.m_btnSubtract = new System.Windows.Forms.Button();
            this.m_btnMultiply = new System.Windows.Forms.Button();
            this.m_lblNumber1 = new System.Windows.Forms.Label();
            this.m_lblNumber2 = new System.Windows.Forms.Label();
            this.m_tbNumber1 = new System.Windows.Forms.TextBox();
            this.m_tbNumber2 = new System.Windows.Forms.TextBox();
            this.m_gbMathematics = new System.Windows.Forms.GroupBox();
            this.m_btnDivide = new System.Windows.Forms.Button();
            this.m_gbNumbers = new System.Windows.Forms.GroupBox();
            this.m_btnIntegers = new System.Windows.Forms.GroupBox();
            this.m_btnDoCalculation = new System.Windows.Forms.Button();
            this.m_gbAdapter = new System.Windows.Forms.GroupBox();
            this.m_rbDoubles = new System.Windows.Forms.RadioButton();
            this.m_rbIntegers = new System.Windows.Forms.RadioButton();
            this.m_gbMathematics.SuspendLayout();
            this.m_gbNumbers.SuspendLayout();
            this.m_btnIntegers.SuspendLayout();
            this.m_gbAdapter.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_tbFinalNumber
            // 
            this.m_tbFinalNumber.Location = new System.Drawing.Point(6, 40);
            this.m_tbFinalNumber.Name = "m_tbFinalNumber";
            this.m_tbFinalNumber.Size = new System.Drawing.Size(117, 20);
            this.m_tbFinalNumber.TabIndex = 0;
            this.m_tbFinalNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_btnAdd
            // 
            this.m_btnAdd.Location = new System.Drawing.Point(6, 19);
            this.m_btnAdd.Name = "m_btnAdd";
            this.m_btnAdd.Size = new System.Drawing.Size(129, 27);
            this.m_btnAdd.TabIndex = 1;
            this.m_btnAdd.Text = "Add";
            this.m_btnAdd.UseVisualStyleBackColor = true;
            this.m_btnAdd.Click += new System.EventHandler(this.m_btnAdd_Click);
            // 
            // m_btnSubtract
            // 
            this.m_btnSubtract.Location = new System.Drawing.Point(6, 52);
            this.m_btnSubtract.Name = "m_btnSubtract";
            this.m_btnSubtract.Size = new System.Drawing.Size(129, 27);
            this.m_btnSubtract.TabIndex = 2;
            this.m_btnSubtract.Text = "Subtract";
            this.m_btnSubtract.UseVisualStyleBackColor = true;
            this.m_btnSubtract.Click += new System.EventHandler(this.m_btnSubtract_Click);
            // 
            // m_btnMultiply
            // 
            this.m_btnMultiply.Location = new System.Drawing.Point(6, 85);
            this.m_btnMultiply.Name = "m_btnMultiply";
            this.m_btnMultiply.Size = new System.Drawing.Size(129, 27);
            this.m_btnMultiply.TabIndex = 3;
            this.m_btnMultiply.Text = "Multiply";
            this.m_btnMultiply.UseVisualStyleBackColor = true;
            this.m_btnMultiply.Click += new System.EventHandler(this.m_btnMultiply_Click);
            // 
            // m_lblNumber1
            // 
            this.m_lblNumber1.AutoSize = true;
            this.m_lblNumber1.Location = new System.Drawing.Point(6, 31);
            this.m_lblNumber1.Name = "m_lblNumber1";
            this.m_lblNumber1.Size = new System.Drawing.Size(66, 13);
            this.m_lblNumber1.TabIndex = 4;
            this.m_lblNumber1.Text = "First Number";
            // 
            // m_lblNumber2
            // 
            this.m_lblNumber2.AutoSize = true;
            this.m_lblNumber2.Location = new System.Drawing.Point(101, 31);
            this.m_lblNumber2.Name = "m_lblNumber2";
            this.m_lblNumber2.Size = new System.Drawing.Size(84, 13);
            this.m_lblNumber2.TabIndex = 5;
            this.m_lblNumber2.Text = "Second Number";
            // 
            // m_tbNumber1
            // 
            this.m_tbNumber1.Location = new System.Drawing.Point(6, 59);
            this.m_tbNumber1.Name = "m_tbNumber1";
            this.m_tbNumber1.Size = new System.Drawing.Size(74, 20);
            this.m_tbNumber1.TabIndex = 6;
            this.m_tbNumber1.Text = "10.5";
            this.m_tbNumber1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_tbNumber2
            // 
            this.m_tbNumber2.Location = new System.Drawing.Point(104, 59);
            this.m_tbNumber2.Name = "m_tbNumber2";
            this.m_tbNumber2.Size = new System.Drawing.Size(79, 20);
            this.m_tbNumber2.TabIndex = 7;
            this.m_tbNumber2.Text = "4.1";
            this.m_tbNumber2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_gbMathematics
            // 
            this.m_gbMathematics.Controls.Add(this.m_btnDivide);
            this.m_gbMathematics.Controls.Add(this.m_btnMultiply);
            this.m_gbMathematics.Controls.Add(this.m_btnSubtract);
            this.m_gbMathematics.Controls.Add(this.m_btnAdd);
            this.m_gbMathematics.Location = new System.Drawing.Point(38, 12);
            this.m_gbMathematics.Name = "m_gbMathematics";
            this.m_gbMathematics.Size = new System.Drawing.Size(141, 149);
            this.m_gbMathematics.TabIndex = 8;
            this.m_gbMathematics.TabStop = false;
            this.m_gbMathematics.Text = "Mathematic Operations";
            // 
            // m_btnDivide
            // 
            this.m_btnDivide.Location = new System.Drawing.Point(6, 118);
            this.m_btnDivide.Name = "m_btnDivide";
            this.m_btnDivide.Size = new System.Drawing.Size(129, 25);
            this.m_btnDivide.TabIndex = 4;
            this.m_btnDivide.Text = "Divide";
            this.m_btnDivide.UseVisualStyleBackColor = true;
            this.m_btnDivide.Click += new System.EventHandler(this.m_btnDivide_Click);
            // 
            // m_gbNumbers
            // 
            this.m_gbNumbers.Controls.Add(this.m_tbNumber2);
            this.m_gbNumbers.Controls.Add(this.m_tbNumber1);
            this.m_gbNumbers.Controls.Add(this.m_lblNumber1);
            this.m_gbNumbers.Controls.Add(this.m_lblNumber2);
            this.m_gbNumbers.Location = new System.Drawing.Point(18, 175);
            this.m_gbNumbers.Name = "m_gbNumbers";
            this.m_gbNumbers.Size = new System.Drawing.Size(192, 88);
            this.m_gbNumbers.TabIndex = 9;
            this.m_gbNumbers.TabStop = false;
            this.m_gbNumbers.Text = "Enter Numbers Here";
            // 
            // m_btnIntegers
            // 
            this.m_btnIntegers.Controls.Add(this.m_tbFinalNumber);
            this.m_btnIntegers.Location = new System.Drawing.Point(242, 176);
            this.m_btnIntegers.Name = "m_btnIntegers";
            this.m_btnIntegers.Size = new System.Drawing.Size(129, 87);
            this.m_btnIntegers.TabIndex = 10;
            this.m_btnIntegers.TabStop = false;
            this.m_btnIntegers.Text = "Result";
            // 
            // m_btnDoCalculation
            // 
            this.m_btnDoCalculation.Location = new System.Drawing.Point(242, 134);
            this.m_btnDoCalculation.Name = "m_btnDoCalculation";
            this.m_btnDoCalculation.Size = new System.Drawing.Size(123, 27);
            this.m_btnDoCalculation.TabIndex = 11;
            this.m_btnDoCalculation.Text = "Perform Calculation";
            this.m_btnDoCalculation.UseVisualStyleBackColor = true;
            this.m_btnDoCalculation.Click += new System.EventHandler(this.m_btnDoCalculation_Click);
            // 
            // m_gbAdapter
            // 
            this.m_gbAdapter.Controls.Add(this.m_rbDoubles);
            this.m_gbAdapter.Controls.Add(this.m_rbIntegers);
            this.m_gbAdapter.Location = new System.Drawing.Point(242, 31);
            this.m_gbAdapter.Name = "m_gbAdapter";
            this.m_gbAdapter.Size = new System.Drawing.Size(123, 71);
            this.m_gbAdapter.TabIndex = 12;
            this.m_gbAdapter.TabStop = false;
            this.m_gbAdapter.Text = "Int or Double";
            // 
            // m_rbDoubles
            // 
            this.m_rbDoubles.AutoSize = true;
            this.m_rbDoubles.Location = new System.Drawing.Point(16, 46);
            this.m_rbDoubles.Name = "m_rbDoubles";
            this.m_rbDoubles.Size = new System.Drawing.Size(64, 17);
            this.m_rbDoubles.TabIndex = 1;
            this.m_rbDoubles.TabStop = true;
            this.m_rbDoubles.Text = "Doubles";
            this.m_rbDoubles.UseVisualStyleBackColor = true;
            this.m_rbDoubles.CheckedChanged += new System.EventHandler(this.m_rbDoubles_CheckedChanged);
            // 
            // m_rbIntegers
            // 
            this.m_rbIntegers.AutoSize = true;
            this.m_rbIntegers.Location = new System.Drawing.Point(16, 23);
            this.m_rbIntegers.Name = "m_rbIntegers";
            this.m_rbIntegers.Size = new System.Drawing.Size(63, 17);
            this.m_rbIntegers.TabIndex = 0;
            this.m_rbIntegers.TabStop = true;
            this.m_rbIntegers.Text = "Integers";
            this.m_rbIntegers.UseVisualStyleBackColor = true;
            this.m_rbIntegers.CheckedChanged += new System.EventHandler(this.m_rbIntegers_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 283);
            this.Controls.Add(this.m_gbAdapter);
            this.Controls.Add(this.m_btnDoCalculation);
            this.Controls.Add(this.m_btnIntegers);
            this.Controls.Add(this.m_gbNumbers);
            this.Controls.Add(this.m_gbMathematics);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.m_gbMathematics.ResumeLayout(false);
            this.m_gbNumbers.ResumeLayout(false);
            this.m_gbNumbers.PerformLayout();
            this.m_btnIntegers.ResumeLayout(false);
            this.m_btnIntegers.PerformLayout();
            this.m_gbAdapter.ResumeLayout(false);
            this.m_gbAdapter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox m_tbFinalNumber;
        private System.Windows.Forms.Button m_btnAdd;
        private System.Windows.Forms.Button m_btnSubtract;
        private System.Windows.Forms.Button m_btnMultiply;
        private System.Windows.Forms.Label m_lblNumber1;
        private System.Windows.Forms.Label m_lblNumber2;
        private System.Windows.Forms.TextBox m_tbNumber1;
        private System.Windows.Forms.TextBox m_tbNumber2;
        private System.Windows.Forms.GroupBox m_gbMathematics;
        private System.Windows.Forms.GroupBox m_gbNumbers;
        private System.Windows.Forms.GroupBox m_btnIntegers;
        private System.Windows.Forms.Button m_btnDoCalculation;
        private System.Windows.Forms.Button m_btnDivide;
        private System.Windows.Forms.GroupBox m_gbAdapter;
        private System.Windows.Forms.RadioButton m_rbDoubles;
        private System.Windows.Forms.RadioButton m_rbIntegers;
    }
}

