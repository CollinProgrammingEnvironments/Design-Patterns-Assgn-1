﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public class Adapter : Target
    {
        private Adaptee adaptee = new Adaptee();

        public int Request(double a)
        {
            int intvalue = adaptee.DoubleNumber1(a);
            return intvalue;
        }
    }
}
