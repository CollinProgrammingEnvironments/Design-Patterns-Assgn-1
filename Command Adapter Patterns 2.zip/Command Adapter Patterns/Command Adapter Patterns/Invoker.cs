﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public class Invoker : Receiver   //calculator
    {
        double _x;
        double _y;

        MathActions currentAction;

        public Invoker (double x, double y)   //constructor
        {
            _x = x;
            _y = y;
        }

        public Invoker()
        {
            // TODO: Complete member initialization
        }

        public void SetAction(MathActions action)
        {
            currentAction = action;
        }

        public double GetResult()
        {
            double result;
            if(currentAction == MathActions.Add)
            {
                result = _x + _y;
            }
            else if (currentAction == MathActions.Subtract)
            {
                result = _x - _y;
            }
            else if (currentAction == MathActions.Multiply)
            {
                result = _x * _y;
            }
            else
            {
                result = _x / _y;
            }

            String.Format("{0:0.00}", result);
            return result;
        }
    }
}
