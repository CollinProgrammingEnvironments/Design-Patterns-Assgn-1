﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command_Adapter_Patterns
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #region Commands, Adapter, Bools

        Receiver calculation = null;
        Command command = null;
        AddCommand addCommand = null;
        SubtractCommand subCommand = null;
        MultiplicationCommand multCommand = null;
        DivideCommand divCommand = null;

        Adapter first = new Adapter();

        private bool IntCheckChecked = false;
        private bool DoubleCheckChecked = false;

        private bool AddButtonPushed = false;
        private bool SubtractButtonPushed = false;
        private bool MultiplyButtonPushed = false;
        private bool DivideButtonPushed = false;

        #endregion

        #region Integer/Double Decision

        private void m_rbIntegers_CheckedChanged(object sender, EventArgs e)
        {
            IntCheckChecked = true;
            DoubleCheckChecked = false;
        }

        private void m_rbDoubles_CheckedChanged(object sender, EventArgs e)
        {
            string s_x = m_tbNumber1.Text;
            double x = StringToDouble.Conversion(s_x.ToString());
            string s_y = m_tbNumber2.Text;
            double y = StringToDouble.Conversion(s_y.ToString());

            calculation = new Invoker(x, y);

            addCommand = new AddCommand(calculation);
            subCommand = new SubtractCommand(calculation);
            multCommand = new MultiplicationCommand(calculation);
            divCommand = new DivideCommand(calculation);

            DoubleCheckChecked = true;
            IntCheckChecked = false;
        }

        #endregion

        #region Click Events For Commands
        private void m_btnAdd_Click(object sender, EventArgs e)
        {
            command = addCommand;
            AddButtonPushed = true;
            
            SubtractButtonPushed = false;
            MultiplyButtonPushed = false;
            DivideButtonPushed = false;
        }

        private void m_btnSubtract_Click(object sender, EventArgs e)
        {
            command = subCommand;
            SubtractButtonPushed = true;
            
            AddButtonPushed = false;
            MultiplyButtonPushed = false;
            DivideButtonPushed = false;
        }

        private void m_btnMultiply_Click(object sender, EventArgs e)
        {
            command = multCommand;
            MultiplyButtonPushed = true;
            
            AddButtonPushed = false;
            SubtractButtonPushed = false;
            DivideButtonPushed = false;
        }

        private void m_btnDivide_Click(object sender, EventArgs e)
        {
            command = divCommand;
            DivideButtonPushed = true;

            AddButtonPushed = false;
            SubtractButtonPushed = false;
            MultiplyButtonPushed = false;
        }
        #endregion

        #region Calculation Click Command

        private void m_btnDoCalculation_Click(object sender, EventArgs e)
        {
            if (IntCheckChecked == true)
            {
                string s_x = m_tbNumber1.Text;
                double x = StringToDouble.Conversion(s_x.ToString());
                string s_y = m_tbNumber2.Text;
                double y = StringToDouble.Conversion(s_y.ToString());

                if (AddButtonPushed == true)
                {
                    double EndResultDouble = x + y;
                    int i_ER = first.Request(EndResultDouble);
                    string s_ER = i_ER.ToString();
                    m_tbFinalNumber.Text = s_ER;
                }
                if (SubtractButtonPushed == true)
                {
                    double EndResultDouble = x - y;
                    int i_ER = first.Request(EndResultDouble);
                    string s_ER = i_ER.ToString();
                    m_tbFinalNumber.Text = s_ER;
                }
                if (MultiplyButtonPushed == true)
                {
                    double EndResultDouble = x * y;
                    int i_ER = first.Request(EndResultDouble);
                    string s_ER = i_ER.ToString();
                    m_tbFinalNumber.Text = s_ER;
                }
                if (DivideButtonPushed == true)
                {
                    double EndResultDouble = x / y;
                    int i_ER = first.Request(EndResultDouble);
                    string s_ER = i_ER.ToString();
                    m_tbFinalNumber.Text = s_ER;
                }
            }
            else if (DoubleCheckChecked == true)
            {
                m_tbFinalNumber.Text = command.Execute().ToString("0.00");
            }
        }
        #endregion
    }
}
