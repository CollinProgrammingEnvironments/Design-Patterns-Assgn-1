﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    public class Adaptee
    {  
        public int DoubleNumber1(double a)
        {
            int doublevalue = System.Convert.ToInt32(a);
            return doublevalue;
        }

    }
}
