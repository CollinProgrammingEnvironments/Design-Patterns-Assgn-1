﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter_Patterns
{
    #region Mathematical Commands for Application

    public class AddCommand : Command
    {
        public AddCommand(Receiver receiver)
            :base(receiver)
        {

        }
        public override double Execute()
        {
            _receiver.SetAction(MathActions.Add);
            return _receiver.GetResult();
        }
    }

    public class SubtractCommand : Command
    {
        public SubtractCommand(Receiver receiver)
            :base(receiver)
        {

        }
        public override double Execute()
        {
            _receiver.SetAction(MathActions.Subtract);
            return _receiver.GetResult();
        }
    }

    public class MultiplicationCommand : Command
    {
        public MultiplicationCommand(Receiver receiver)
            :base(receiver)
        {

        }
        public override double Execute()
        {
            _receiver.SetAction(MathActions.Multiply);
            return _receiver.GetResult();
        }
    }
    
    public class DivideCommand : Command
    {
        public DivideCommand(Receiver receiver)
            :base(receiver)
        {

        }
        public override double Execute()
        {
            _receiver.SetAction(MathActions.Divide);
            return _receiver.GetResult();
        }
    }

    #endregion
}
