//MatrixMultiplication.cpp - Collin Kemner - February 1st, 2017
//This application will conduct a matrix multiplication operation between two matrices of
//equal or different size

#include <iostream>;
#include <string>;

using namespace std;

int main()
{
	string keepInWhileLoop = "On";

	while (keepInWhileLoop == "On")
	{
		string matrixDecision;

		cout << "Select the kind of matrices you would like to multiply: 2x2 * 2x2 (1), 3x1 * 1x3 (2), 1x2 * 2x1 (3), or 3x3 * 3x3 (4)." << endl;  //select matrix to
		cin >> matrixDecision;                                                                                                                     //multiply
		cout << endl;

		/*
			Decision 1: 2x2 * 2x2 = 2x2 matrix
		*/	
		if (matrixDecision == "1")
		{
			string confirmation;          //string for number confirmation
			int resultantMatrix[2][2];      //matrix that will be the final matrix
			int Matrix1_2x2[2][2];        //matrix 1
			int Matrix2_2x2[2][2];       //matrix 2

			int Input;       //variable to store integers going into the array

			for (int i = 0; i < 2; i++)        //input integers into matrix 1
			{
				for (int j = 0; j < 2; j++)
				{
					cout << "Select numbers for matrix 1: ";
					cin >> Input;
					Matrix1_2x2[i][j] = Input;
					cout << endl;
				}
			}

			for (int i = 0; i < 2; i++)             //input integers into matrix 2
			{
				for (int j = 0; j < 2; j++)
				{
					cout << "Select numbers for matrix 2: ";
					cin >> Input;
					Matrix2_2x2[i][j] = Input;
					cout << endl;
				}
			}

			cout << endl;
			cout << "Confirm your selection (y/n): ";       //confirm number selection
			cin >> confirmation;
			cout << endl;

			if (confirmation == "y")      // confirmation equals "y"
			{

				for (int i = 0; i < 2; i++)       //multiplication algorithm
				{
					for (int j = 0; j < 2; j++)
					{
						resultantMatrix[i][j] = 0;
						for (int k = 0; k < 1; k++)
						{
							resultantMatrix[i][j] = resultantMatrix[i][j] + (Matrix1_2x2[i][k] * Matrix2_2x2[k][j]);
						}
					}
				}

				cout << "The resultant matrix is: " << endl;
				
				for (int i = 0; i < 2; i++)       //display algorithm
				{
					for (int j = 0; j < 2; j++)
					{
						cout << resultantMatrix[i][j] << " ";
					}
					cout << endl;
				}

				cout << endl << endl;

				keepInWhileLoop = "On";
			}
			else if (confirmation == "n")       //if confirmation equals "n"
			{
				keepInWhileLoop = "On";
			}
		}
		
		/*
			Decision 2: 3x1 * 1x3 = 3x3 matrix
		*/	
		else if (matrixDecision == "2")
		{
			string confirmation;          //string for number confirmation
			int resultantMatrix[3][3];      //matrix that will be the final matrix
			int Matrix1_3x1[3][1];        //matrix 1
			int Matrix2_1x3[1][3];       //matrix 2

			int Input;       //variable to store integers going into the array

			for (int i = 0; i < 3; i++)        //input integers into matrix 1
			{
				for (int j = 0; j < 1; j++)
				{
					cout << "Select numbers for matrix 1: ";
					cin >> Input;
					Matrix1_3x1[i][j] = Input;
					cout << endl;
				}
			}

			for (int i = 0; i < 1; i++)             //input integers into matrix 2
			{
				for (int j = 0; j < 3; j++)
				{
					cout << "Select numbers for matrix 2: ";
					cin >> Input;
					Matrix2_1x3[i][j] = Input;
					cout << endl;
				}
			}

			cout << endl;
			cout << "Confirm your selection (y/n): ";       //confirm number selection
			cin >> confirmation;
			cout << endl;

			if (confirmation == "y")      // confirmation equals "y"
			{

				for (int i = 0; i < 3; i++)       //multiplication algorithm
				{
					for (int j = 0; j < 3; j++)
					{
						resultantMatrix[i][j] = 0;
						for (int k = 0; k < 1; k++)
						{
							resultantMatrix[i][j] = resultantMatrix[i][j] + (Matrix1_3x1[i][k] * Matrix2_1x3[k][j]);
						}
					}
				}

				cout << "The resultant matrix is: " << endl;

				for (int i = 0; i < 3; i++)       //display algorithm
				{
					for (int j = 0; j < 3; j++)
					{
						cout << resultantMatrix[i][j] << " ";
					}
					cout << endl;
				}

				cout << endl << endl;

				keepInWhileLoop = "On";
			}
			else if (confirmation == "n")       //if confirmation equals "n"
			{
				keepInWhileLoop = "On";
			}
		}

		
		/*
			Decision 3: 1x2 * 2x1 = 1x1 matrix
		*/
		else if (matrixDecision == "3")
		{
			string confirmation;          //string for number confirmation
			int resultantMatrix[1][1];      //matrix that will be the final matrix
			int Matrix1_1x2[1][2];        //matrix 1
			int Matrix2_2x1[2][1];       //matrix 2

			int Input;       //variable to store integers going into the array

			for (int i = 0; i < 1; i++)        //input integers into matrix 1
			{
				for (int j = 0; j < 2; j++)
				{
					cout << "Select numbers for matrix 1: ";
					cin >> Input;
					Matrix1_1x2[i][j] = Input;
					cout << endl;
				}
			}

			for (int i = 0; i < 2; i++)             //input integers into matrix 2
			{
				for (int j = 0; j < 1; j++)
				{
					cout << "Select numbers for matrix 2: ";
					cin >> Input;
					Matrix2_2x1[i][j] = Input;
					cout << endl;
				}
			}

			cout << endl;
			cout << "Confirm your selection (y/n): ";       //confirm number selection
			cin >> confirmation;
			cout << endl;

			if (confirmation == "y")      // confirmation equals "y"
			{

				for (int i = 0; i < 1; i++)       //multiplication algorithm
				{
					for (int j = 0; j < 1; j++)
					{
						resultantMatrix[i][j] = 0;
						for (int k = 0; k < 1; k++)
						{
							resultantMatrix[i][j] = resultantMatrix[i][j] + (Matrix1_1x2[i][k] * Matrix2_2x1[k][j]);
						}
					}
				}

				cout << "The resultant matrix is: " << endl;

				for (int i = 0; i < 1; i++)       //display algorithm
				{
					for (int j = 0; j < 1; j++)
					{
						cout << resultantMatrix[i][j] << " ";
					}
					cout << endl;
				}

				cout << endl << endl;

				keepInWhileLoop = "On";
			}
			else if (confirmation == "n")       //if confirmation equals "n"
			{
				keepInWhileLoop = "On";
			}
		}

		/*
			Decision 4: 3x3 * 3x3 = 3x3 matrix
		*/
		if (matrixDecision == "4")
		{
			string confirmation;          //string for number confirmation
			int resultantMatrix[3][3];      //matrix that will be the final matrix
			int Matrix1_3x3[3][3];        //matrix 1
			int Matrix2_3x3[3][3];       //matrix 2

			int Input;       //variable to store integers going into the array

			for (int i = 0; i < 3; i++)        //input integers into matrix 1
			{
				for (int j = 0; j < 3; j++)
				{
					cout << "Select numbers for matrix 1: ";
					cin >> Input;
					Matrix1_3x3[i][j] = Input;
					cout << endl;
				}
			}

			for (int i = 0; i < 3; i++)             //input integers into matrix 2
			{
				for (int j = 0; j < 3; j++)
				{
					cout << "Select numbers for matrix 2: ";
					cin >> Input;
					Matrix2_3x3[i][j] = Input;
					cout << endl;
				}
			}

			cout << endl;
			cout << "Confirm your selection (y/n): ";       //confirm number selection
			cin >> confirmation;
			cout << endl;

			if (confirmation == "y")      // confirmation equals "y"
			{

				for (int i = 0; i < 3; i++)       //multiplication algorithm
				{
					for (int j = 0; j < 3; j++)
					{
						resultantMatrix[i][j] = 0;
						for (int k = 0; k < 3; k++)
						{
							resultantMatrix[i][j] = resultantMatrix[i][j] + (Matrix1_3x3[i][k] * Matrix2_3x3[k][j]);
						}
					}
				}

				cout << "The resultant matrix is: " << endl;

				for (int i = 0; i < 3; i++)       //display algorithm
				{
					for (int j = 0; j < 3; j++)
					{
						cout << resultantMatrix[i][j] << " ";
					}
					cout << endl;
				}

				cout << endl << endl;

				keepInWhileLoop = "On";
			}
			else if (confirmation == "n")       //if confirmation equals "n"
			{
				keepInWhileLoop = "On";
			}
		}
		else if (matrixDecision == "end")
		{
			cout << "Goodbye!" << endl << endl;
			return 0;
		}
	}

	return 0;
}