﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy_Pattern
{
    public interface IStrategy
    {
        string moveCommand(string name);
        string friendlinessCommand(string name);
        string alertnessCommand(string name);
        string trustCommand(string name);
    }
}
