﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy_Pattern
{
    public class AggressiveBehavior : IStrategy
    {
        public string moveCommand(string name)
        {
            return name + " will move in an aggressive fashion.";
        }
        public string friendlinessCommand(string name)
        {
            return name + "'s friendliness will go down.";
        }
        public string alertnessCommand(string name)
        {
            return name + " will become more alert and will act aggressively towards any threat.";
        }
        public string trustCommand(string name)
        {
            return name + "'s trust with strangers will go down.";
        }
    }

    public class DefensiveBehavior : IStrategy
    {
        public string moveCommand(string name)
        {
            return name + " will move in a cautious, defensive fashion.";
        }
        public string friendlinessCommand(string name)
        {
            return name + "'s friendliness will go down.";
        }
        public string alertnessCommand(string name)
        {
            return name + " will become more alert and will act in a defensive manner on behalf of its owner.";
        }
        public string trustCommand(string name)
        {
            return name + "'s trust with strangers will go down.";
        }
    }

    public class NormalBehavior : IStrategy
    {
        public string moveCommand(string name)
        {
            return name + " will move on as normal.";
        }
        public string friendlinessCommand(string name)
        {
            return name + "'s friendliness will be at a normal level.";
        }
        public string alertnessCommand(string name)
        {
            return name + "'s alertness will be lower.";
        }
        public string trustCommand(string name)
        {
            return name + "'s trust with strangers will be good.";
        }
    }
}
