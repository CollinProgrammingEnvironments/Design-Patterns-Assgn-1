﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Strategy_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Dog d1 = new Dog(new AggressiveBehavior());
        Dog d2 = new Dog(new DefensiveBehavior());
        Dog d3 = new Dog(new NormalBehavior());

        private void m_btnAggressive_Click(object sender, EventArgs e)
        {
            m_tbDisplay.Text = d1.move(m_tbName.Text) + System.Environment.NewLine + d1.friendliness(m_tbName.Text) + System.Environment.NewLine + d1.alertness(m_tbName.Text) + System.Environment.NewLine + d1.trust(m_tbName.Text) + System.Environment.NewLine;
        }

        private void m_btnDefensive_Click(object sender, EventArgs e)
        {
            m_tbDisplay.Text = d2.move(m_tbName.Text) + System.Environment.NewLine + d2.friendliness(m_tbName.Text) + System.Environment.NewLine + d2.alertness(m_tbName.Text) + System.Environment.NewLine + d2.trust(m_tbName.Text) + System.Environment.NewLine;
        }

        private void m_btnNormal_Click(object sender, EventArgs e)
        {
            m_tbDisplay.Text = d3.move(m_tbName.Text) + System.Environment.NewLine + d3.friendliness(m_tbName.Text) + System.Environment.NewLine + d3.alertness(m_tbName.Text) + System.Environment.NewLine + d3.trust(m_tbName.Text) + System.Environment.NewLine;
        }
        
        
    }
}
