﻿namespace Strategy_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_tbDisplay = new System.Windows.Forms.TextBox();
            this.m_btnNormal = new System.Windows.Forms.Button();
            this.m_btnAggressive = new System.Windows.Forms.Button();
            this.m_btnDefensive = new System.Windows.Forms.Button();
            this.m_tbName = new System.Windows.Forms.TextBox();
            this.m_gbName = new System.Windows.Forms.GroupBox();
            this.m_gbBehaviors = new System.Windows.Forms.GroupBox();
            this.m_gbName.SuspendLayout();
            this.m_gbBehaviors.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_tbDisplay
            // 
            this.m_tbDisplay.Location = new System.Drawing.Point(97, 99);
            this.m_tbDisplay.Multiline = true;
            this.m_tbDisplay.Name = "m_tbDisplay";
            this.m_tbDisplay.Size = new System.Drawing.Size(327, 88);
            this.m_tbDisplay.TabIndex = 0;
            // 
            // m_btnNormal
            // 
            this.m_btnNormal.Location = new System.Drawing.Point(6, 109);
            this.m_btnNormal.Name = "m_btnNormal";
            this.m_btnNormal.Size = new System.Drawing.Size(75, 34);
            this.m_btnNormal.TabIndex = 1;
            this.m_btnNormal.Text = "Normal Stance";
            this.m_btnNormal.UseVisualStyleBackColor = true;
            this.m_btnNormal.Click += new System.EventHandler(this.m_btnNormal_Click);
            // 
            // m_btnAggressive
            // 
            this.m_btnAggressive.Location = new System.Drawing.Point(6, 19);
            this.m_btnAggressive.Name = "m_btnAggressive";
            this.m_btnAggressive.Size = new System.Drawing.Size(75, 44);
            this.m_btnAggressive.TabIndex = 2;
            this.m_btnAggressive.Text = "Aggressive Stance";
            this.m_btnAggressive.UseVisualStyleBackColor = true;
            this.m_btnAggressive.Click += new System.EventHandler(this.m_btnAggressive_Click);
            // 
            // m_btnDefensive
            // 
            this.m_btnDefensive.Location = new System.Drawing.Point(6, 69);
            this.m_btnDefensive.Name = "m_btnDefensive";
            this.m_btnDefensive.Size = new System.Drawing.Size(75, 34);
            this.m_btnDefensive.TabIndex = 3;
            this.m_btnDefensive.Text = "Defensive Stance";
            this.m_btnDefensive.UseVisualStyleBackColor = true;
            this.m_btnDefensive.Click += new System.EventHandler(this.m_btnDefensive_Click);
            // 
            // m_tbName
            // 
            this.m_tbName.Location = new System.Drawing.Point(6, 13);
            this.m_tbName.Name = "m_tbName";
            this.m_tbName.Size = new System.Drawing.Size(117, 20);
            this.m_tbName.TabIndex = 4;
            this.m_tbName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_gbName
            // 
            this.m_gbName.Controls.Add(this.m_tbName);
            this.m_gbName.Location = new System.Drawing.Point(149, 12);
            this.m_gbName.Name = "m_gbName";
            this.m_gbName.Size = new System.Drawing.Size(133, 39);
            this.m_gbName.TabIndex = 5;
            this.m_gbName.TabStop = false;
            this.m_gbName.Text = "Enter Name";
            // 
            // m_gbBehaviors
            // 
            this.m_gbBehaviors.Controls.Add(this.m_btnAggressive);
            this.m_gbBehaviors.Controls.Add(this.m_btnDefensive);
            this.m_gbBehaviors.Controls.Add(this.m_btnNormal);
            this.m_gbBehaviors.Location = new System.Drawing.Point(4, 67);
            this.m_gbBehaviors.Name = "m_gbBehaviors";
            this.m_gbBehaviors.Size = new System.Drawing.Size(87, 148);
            this.m_gbBehaviors.TabIndex = 6;
            this.m_gbBehaviors.TabStop = false;
            this.m_gbBehaviors.Text = "Behaviors";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 226);
            this.Controls.Add(this.m_gbBehaviors);
            this.Controls.Add(this.m_gbName);
            this.Controls.Add(this.m_tbDisplay);
            this.Name = "Form1";
            this.Text = "Dog Behavior Simulation";
            this.m_gbName.ResumeLayout(false);
            this.m_gbName.PerformLayout();
            this.m_gbBehaviors.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnNormal;
        private System.Windows.Forms.Button m_btnAggressive;
        private System.Windows.Forms.Button m_btnDefensive;
        public System.Windows.Forms.TextBox m_tbDisplay;
        private System.Windows.Forms.TextBox m_tbName;
        private System.Windows.Forms.GroupBox m_gbName;
        private System.Windows.Forms.GroupBox m_gbBehaviors;
    }
}

