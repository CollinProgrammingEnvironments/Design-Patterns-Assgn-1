﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy_Pattern
{
    public class Dog
    {
        IStrategy behavior;

        public Dog(IStrategy _behavior)
        {
            this.behavior = _behavior;
        }

        public string move(string name)
        {
            return this.behavior.moveCommand(name);
        }
        public string friendliness(string name)
        {
            return this.behavior.friendlinessCommand(name);
        }
        public string alertness(string name)
        {
            return this.behavior.alertnessCommand(name);
        }
        public string trust(string name)
        {
            return this.behavior.trustCommand(name);
        }
    }
}
