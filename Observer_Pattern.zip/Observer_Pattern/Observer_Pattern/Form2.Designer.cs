﻿namespace Observer_Pattern
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_tbName = new System.Windows.Forms.TextBox();
            this.m_lblName = new System.Windows.Forms.Label();
            this.m_btnSendText = new System.Windows.Forms.Button();
            this.m_tbTexting = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_tbName
            // 
            this.m_tbName.Location = new System.Drawing.Point(56, 23);
            this.m_tbName.Name = "m_tbName";
            this.m_tbName.Size = new System.Drawing.Size(87, 20);
            this.m_tbName.TabIndex = 0;
            this.m_tbName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_lblName
            // 
            this.m_lblName.AutoSize = true;
            this.m_lblName.Location = new System.Drawing.Point(12, 23);
            this.m_lblName.Name = "m_lblName";
            this.m_lblName.Size = new System.Drawing.Size(38, 13);
            this.m_lblName.TabIndex = 1;
            this.m_lblName.Text = "Name:";
            // 
            // m_btnSendText
            // 
            this.m_btnSendText.Location = new System.Drawing.Point(119, 255);
            this.m_btnSendText.Name = "m_btnSendText";
            this.m_btnSendText.Size = new System.Drawing.Size(91, 22);
            this.m_btnSendText.TabIndex = 3;
            this.m_btnSendText.Text = "Send Text";
            this.m_btnSendText.UseVisualStyleBackColor = true;
            //this.m_btnSendText.Click += new System.EventHandler(this.m_btnSendText_Click);
            // 
            // m_tbTexting
            // 
            this.m_tbTexting.Location = new System.Drawing.Point(70, 49);
            this.m_tbTexting.Multiline = true;
            this.m_tbTexting.Name = "m_tbTexting";
            this.m_tbTexting.Size = new System.Drawing.Size(193, 200);
            this.m_tbTexting.TabIndex = 4;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 289);
            this.Controls.Add(this.m_tbTexting);
            this.Controls.Add(this.m_btnSendText);
            this.Controls.Add(this.m_lblName);
            this.Controls.Add(this.m_tbName);
            this.Name = "Form2";
            this.Text = "Messaging Phone";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_tbName;
        private System.Windows.Forms.Label m_lblName;
        private System.Windows.Forms.Button m_btnSendText;
        private System.Windows.Forms.TextBox m_tbTexting;
    }
}