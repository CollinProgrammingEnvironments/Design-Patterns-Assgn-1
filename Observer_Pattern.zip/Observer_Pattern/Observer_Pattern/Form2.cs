﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Observer_Pattern
{
    public partial class Form2 : Form
    {
        public Form2()   //constructor for form2
        {
            InitializeComponent();
        }
        
        public delegate void NewTextEventHandler(object sender, TextingEventArgs e);   //event handler
        public event NewTextEventHandler NewTextEntered;
        private string _Name;      //string for constructor
        private string _Text;      //string for constructor

        public string m_Name   //constructor for name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string m_Text     //constructor for text
        {
            get { return _Text; }
            set { _Text = value; }
        }

        public Form2(string Name)         //form2 constructor that contains text and name
        {
            InitializeComponent();
            m_Name = Name;
            m_Text = Text;
        }  
        
        private void Form2_Connection(object sender, EventArgs i)  
        {
            m_tbName.Text = m_Name;
            m_tbTexting.Text = m_Text;
        }
        
        private void m_btnSendText_Click(object sender, TextingEventArgs i)    //event handler for text change
        {
            if (m_tbTexting.Text.Length != 0 && m_tbName.Text.Length != 0)   //if the amount of text in the text box
            {                                                                //is greater than 0, then send text
                if (NewTextEntered != null)
                    NewTextEntered(this, new TextingEventArgs(m_tbName.Text, m_tbTexting.Text));
            }
        }
    }

    //passes through event handlers to the subscribed
    public class TextingEventArgs : EventArgs
    {
        private string _Name;
        private string _Text;

        public string m_Name
        {
            get { return _Name; }
            set
            {
                _Name = value;
            }
        }

        public string m_Text
        {
            get { return _Text; }
            set
            {
                _Text = value;
            }
        }

        public TextingEventArgs(string Name, string Text)
        {
            _Name = Name;
            _Text = Text;
        }
    }
}
