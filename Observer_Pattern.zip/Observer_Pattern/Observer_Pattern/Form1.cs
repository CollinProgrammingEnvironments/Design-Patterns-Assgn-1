﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Observer_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()  //form1 constructor
        {
            InitializeComponent();
        }

        private void m_btnNewPhone_Click(object sender, EventArgs i)     //click event for form2
        {
            Form2 f2 = new Form2();

            f2.NewTextEntered += new Form2.NewTextEventHandler(f2_NewTextEntered);
            f2.Show();
        }

        void f2_NewTextEntered_1(object sender, TextingEventArgs i)
        {
            this.Text = "New text from: " + i.m_Name;
        }

        void f2_NewTextEntered(object sender, TextingEventArgs i)   //event for if new text has been entered
        {
            string TextHasBeenEntered;

            TextHasBeenEntered = i.m_Name + i.m_Text;
            m_lbMessageBox.Text = TextHasBeenEntered + Environment.NewLine + m_lbMessageBox.Text;   //send text to message box
        }

        private void m_btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
