﻿namespace Observer_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_lbMessageBox = new System.Windows.Forms.ListBox();
            this.m_btnNewPhone = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_lbMessageBox
            // 
            this.m_lbMessageBox.FormattingEnabled = true;
            this.m_lbMessageBox.Location = new System.Drawing.Point(61, 77);
            this.m_lbMessageBox.Name = "m_lbMessageBox";
            this.m_lbMessageBox.Size = new System.Drawing.Size(237, 225);
            this.m_lbMessageBox.TabIndex = 0;
            // 
            // m_btnNewPhone
            // 
            this.m_btnNewPhone.Location = new System.Drawing.Point(26, 25);
            this.m_btnNewPhone.Name = "m_btnNewPhone";
            this.m_btnNewPhone.Size = new System.Drawing.Size(105, 24);
            this.m_btnNewPhone.TabIndex = 1;
            this.m_btnNewPhone.Text = "Open New Phone";
            this.m_btnNewPhone.UseVisualStyleBackColor = true;
            this.m_btnNewPhone.Click += new System.EventHandler(this.m_btnNewPhone_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 314);
            this.Controls.Add(this.m_btnNewPhone);
            this.Controls.Add(this.m_lbMessageBox);
            this.Name = "Form1";
            this.Text = "Phone Screen";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox m_lbMessageBox;
        private System.Windows.Forms.Button m_btnNewPhone;
    }
}

