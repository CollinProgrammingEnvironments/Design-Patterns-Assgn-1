﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_Method_Pattern
{
    public class AtHomeConcrete : NightlyActivities //the ConcreteClass
    {
        public override string DrinkingSubstances()
        {
            return "Drinks: Water, milk";
        }

        public override string Language()
        {
            return "Language: Highly restricted";
        }

        public override string Clothes()
        {
            return "Clothes: Conservative";
        }

        public override string Activities()
        {
            return "Activities: Shopping, cleaning, sleeping, eating, nothing fun";
        }
    }
}
