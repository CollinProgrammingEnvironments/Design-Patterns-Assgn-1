﻿namespace Template_Method_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.m_tbNightlyActivities = new System.Windows.Forms.TextBox();
            this.m_rbAtHome = new System.Windows.Forms.RadioButton();
            this.m_rbAtSchool = new System.Windows.Forms.RadioButton();
            this.m_btnNight = new System.Windows.Forms.Button();
            this.m_rbConcert = new System.Windows.Forms.RadioButton();
            this.m_lblPath = new System.Windows.Forms.Label();
            this.m_pnlImage = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // m_tbNightlyActivities
            // 
            this.m_tbNightlyActivities.Location = new System.Drawing.Point(12, 125);
            this.m_tbNightlyActivities.Multiline = true;
            this.m_tbNightlyActivities.Name = "m_tbNightlyActivities";
            this.m_tbNightlyActivities.Size = new System.Drawing.Size(325, 174);
            this.m_tbNightlyActivities.TabIndex = 0;
            // 
            // m_rbAtHome
            // 
            this.m_rbAtHome.AutoSize = true;
            this.m_rbAtHome.Location = new System.Drawing.Point(12, 46);
            this.m_rbAtHome.Name = "m_rbAtHome";
            this.m_rbAtHome.Size = new System.Drawing.Size(66, 17);
            this.m_rbAtHome.TabIndex = 1;
            this.m_rbAtHome.TabStop = true;
            this.m_rbAtHome.Text = "At Home";
            this.m_rbAtHome.UseVisualStyleBackColor = true;
            // 
            // m_rbAtSchool
            // 
            this.m_rbAtSchool.AutoSize = true;
            this.m_rbAtSchool.Location = new System.Drawing.Point(141, 46);
            this.m_rbAtSchool.Name = "m_rbAtSchool";
            this.m_rbAtSchool.Size = new System.Drawing.Size(71, 17);
            this.m_rbAtSchool.TabIndex = 2;
            this.m_rbAtSchool.TabStop = true;
            this.m_rbAtSchool.Text = "At School";
            this.m_rbAtSchool.UseVisualStyleBackColor = true;
            // 
            // m_btnNight
            // 
            this.m_btnNight.Location = new System.Drawing.Point(124, 96);
            this.m_btnNight.Name = "m_btnNight";
            this.m_btnNight.Size = new System.Drawing.Size(106, 23);
            this.m_btnNight.TabIndex = 3;
            this.m_btnNight.Text = "Initiate the night!";
            this.m_btnNight.UseVisualStyleBackColor = true;
            this.m_btnNight.Click += new System.EventHandler(this.m_btnNight_Click);
            // 
            // m_rbConcert
            // 
            this.m_rbConcert.AutoSize = true;
            this.m_rbConcert.Location = new System.Drawing.Point(253, 46);
            this.m_rbConcert.Name = "m_rbConcert";
            this.m_rbConcert.Size = new System.Drawing.Size(84, 17);
            this.m_rbConcert.TabIndex = 4;
            this.m_rbConcert.TabStop = true;
            this.m_rbConcert.Text = "At a Concert";
            this.m_rbConcert.UseVisualStyleBackColor = true;
            // 
            // m_lblPath
            // 
            this.m_lblPath.AutoSize = true;
            this.m_lblPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblPath.Location = new System.Drawing.Point(106, 9);
            this.m_lblPath.Name = "m_lblPath";
            this.m_lblPath.Size = new System.Drawing.Size(148, 24);
            this.m_lblPath.TabIndex = 5;
            this.m_lblPath.Text = "Pick your path!";
            // 
            // m_pnlImage
            // 
            this.m_pnlImage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_pnlImage.BackgroundImage")));
            this.m_pnlImage.Location = new System.Drawing.Point(343, 9);
            this.m_pnlImage.Name = "m_pnlImage";
            this.m_pnlImage.Size = new System.Drawing.Size(300, 300);
            this.m_pnlImage.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 311);
            this.Controls.Add(this.m_pnlImage);
            this.Controls.Add(this.m_lblPath);
            this.Controls.Add(this.m_rbConcert);
            this.Controls.Add(this.m_btnNight);
            this.Controls.Add(this.m_rbAtSchool);
            this.Controls.Add(this.m_rbAtHome);
            this.Controls.Add(this.m_tbNightlyActivities);
            this.Name = "Form1";
            this.Text = "Weekend Simulator 2016";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton m_rbAtHome;
        private System.Windows.Forms.RadioButton m_rbAtSchool;
        public System.Windows.Forms.TextBox m_tbNightlyActivities;
        private System.Windows.Forms.Button m_btnNight;
        private System.Windows.Forms.RadioButton m_rbConcert;
        private System.Windows.Forms.Label m_lblPath;
        private System.Windows.Forms.Panel m_pnlImage;
    }
}

