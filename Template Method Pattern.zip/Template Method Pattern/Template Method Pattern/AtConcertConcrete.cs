﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_Method_Pattern
{
    public class AtConcertConcrete : NightlyActivities //the ConcreteClass
    {
        public override string DrinkingSubstances()
        {
            return "Drinks: Lots of C2H6O";
        }

        public override string Language()
        {
            return "Language: What is PC?";
        }

        public override string Clothes()
        {
            return "Clothes: Clothes with holes";
        }

        public override string Activities()
        {
            return "Activities: Headbanging, stage-diving, crowd-surfing, getting hearing aids in about 30 years";
        }
    }
}
