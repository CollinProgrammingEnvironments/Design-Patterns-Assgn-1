﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_Method_Pattern
{
    public class AtCollegeConcrete : NightlyActivities //the ConcreteClass
    {
        public override string DrinkingSubstances()
        {
            return "Drinks: Water, Soda, drinks that contain C2H6O";
        }

        public override string Language()
        {
            return "Language: Unrestricted";
        }

        public override string Clothes()
        {
            return "Clothes: Provocative";
        }

        public override string Activities()
        {
            return "Activities: Parties, hood shenanigans, robbing banks, forming my own cult, ect.";
        }
    }
}
