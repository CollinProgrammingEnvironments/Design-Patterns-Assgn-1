﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Template_Method_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void m_btnNight_Click(object sender, EventArgs e)
        {
            NightlyActivities ac = new AtCollegeConcrete();
            NightlyActivities ah = new AtHomeConcrete();
            NightlyActivities acon = new AtConcertConcrete();

            if (m_rbAtSchool.Checked)
            {
                m_tbNightlyActivities.Text = ac.InitiateTheNight();
                m_pnlImage.BackgroundImage = System.Drawing.Bitmap.FromFile(@"C:\Users\c-kemner\Documents\201603_0144_ddaac_sm.jpg");
            }
            else if (m_rbAtHome.Checked)
            {
                m_tbNightlyActivities.Text = ah.InitiateTheNight();
                m_pnlImage.BackgroundImage = System.Drawing.Bitmap.FromFile(@"C:\Users\c-kemner\Documents\angry-child-outbursts.jpg");
            }
            else if (m_rbConcert.Checked)
            {
                m_tbNightlyActivities.Text = acon.InitiateTheNight();
                m_pnlImage.BackgroundImage = System.Drawing.Bitmap.FromFile
                    (@"C:\Users\c-kemner\Documents\concert-smoke-crowd-people-concert-music-youth-club-photos-crowd-cheering-the-mood-the-smoke-tools-136417-2560x14401-990x420-300x300.jpg");
            }
        }
    }
}
