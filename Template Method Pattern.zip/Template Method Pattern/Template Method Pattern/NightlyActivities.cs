﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_Method_Pattern
{
    public abstract class NightlyActivities   //the AbstractClass
    {
        public abstract string DrinkingSubstances();
        public abstract string Language();
        public abstract string Clothes();
        public abstract string Activities();

        public string InitiateTheNight()
        {
            List<string> listOfActivities = new List<string>
            {
                DrinkingSubstances(), Language(), Clothes(), Activities()
            };

            string Altogether = "";
            
            for (int i = 0; i < 4; i++)
            {
                Altogether += listOfActivities[i] + System.Environment.NewLine + System.Environment.NewLine;
            }
            
            return Altogether;
        }
    }
}
