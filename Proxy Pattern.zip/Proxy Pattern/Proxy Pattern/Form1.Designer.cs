﻿namespace Proxy_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_btnAdd = new System.Windows.Forms.Button();
            this.m_btnSubtract = new System.Windows.Forms.Button();
            this.m_btnMultiply = new System.Windows.Forms.Button();
            this.m_btnDivide = new System.Windows.Forms.Button();
            this.m_tbAnswer = new System.Windows.Forms.TextBox();
            this.m_gbAnswer = new System.Windows.Forms.GroupBox();
            this.m_gbAnswer.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_btnAdd
            // 
            this.m_btnAdd.Location = new System.Drawing.Point(86, 12);
            this.m_btnAdd.Name = "m_btnAdd";
            this.m_btnAdd.Size = new System.Drawing.Size(76, 23);
            this.m_btnAdd.TabIndex = 0;
            this.m_btnAdd.Text = "Add";
            this.m_btnAdd.UseVisualStyleBackColor = true;
            this.m_btnAdd.Click += new System.EventHandler(this.m_btnAdd_Click);
            // 
            // m_btnSubtract
            // 
            this.m_btnSubtract.Location = new System.Drawing.Point(86, 41);
            this.m_btnSubtract.Name = "m_btnSubtract";
            this.m_btnSubtract.Size = new System.Drawing.Size(76, 27);
            this.m_btnSubtract.TabIndex = 1;
            this.m_btnSubtract.Text = "Subtract";
            this.m_btnSubtract.UseVisualStyleBackColor = true;
            this.m_btnSubtract.Click += new System.EventHandler(this.m_btnSubtract_Click);
            // 
            // m_btnMultiply
            // 
            this.m_btnMultiply.Location = new System.Drawing.Point(86, 74);
            this.m_btnMultiply.Name = "m_btnMultiply";
            this.m_btnMultiply.Size = new System.Drawing.Size(76, 26);
            this.m_btnMultiply.TabIndex = 2;
            this.m_btnMultiply.Text = "Multiply";
            this.m_btnMultiply.UseVisualStyleBackColor = true;
            this.m_btnMultiply.Click += new System.EventHandler(this.m_btnMultiply_Click);
            // 
            // m_btnDivide
            // 
            this.m_btnDivide.Location = new System.Drawing.Point(86, 106);
            this.m_btnDivide.Name = "m_btnDivide";
            this.m_btnDivide.Size = new System.Drawing.Size(76, 23);
            this.m_btnDivide.TabIndex = 3;
            this.m_btnDivide.Text = "Divide";
            this.m_btnDivide.UseVisualStyleBackColor = true;
            this.m_btnDivide.Click += new System.EventHandler(this.m_btnDivide_Click);
            // 
            // m_tbAnswer
            // 
            this.m_tbAnswer.Location = new System.Drawing.Point(6, 29);
            this.m_tbAnswer.Name = "m_tbAnswer";
            this.m_tbAnswer.Size = new System.Drawing.Size(100, 20);
            this.m_tbAnswer.TabIndex = 4;
            this.m_tbAnswer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_gbAnswer
            // 
            this.m_gbAnswer.Controls.Add(this.m_tbAnswer);
            this.m_gbAnswer.Location = new System.Drawing.Point(65, 157);
            this.m_gbAnswer.Name = "m_gbAnswer";
            this.m_gbAnswer.Size = new System.Drawing.Size(113, 55);
            this.m_gbAnswer.TabIndex = 5;
            this.m_gbAnswer.TabStop = false;
            this.m_gbAnswer.Text = "Answer";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(241, 229);
            this.Controls.Add(this.m_gbAnswer);
            this.Controls.Add(this.m_btnDivide);
            this.Controls.Add(this.m_btnMultiply);
            this.Controls.Add(this.m_btnSubtract);
            this.Controls.Add(this.m_btnAdd);
            this.Name = "Form1";
            this.Text = "The Proxy Calculator";
            this.m_gbAnswer.ResumeLayout(false);
            this.m_gbAnswer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button m_btnAdd;
        private System.Windows.Forms.Button m_btnSubtract;
        private System.Windows.Forms.Button m_btnMultiply;
        private System.Windows.Forms.Button m_btnDivide;
        private System.Windows.Forms.TextBox m_tbAnswer;
        private System.Windows.Forms.GroupBox m_gbAnswer;
    }
}

