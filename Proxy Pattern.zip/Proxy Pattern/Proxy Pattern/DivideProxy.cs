﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proxy_Pattern
{
    public partial class DivideProxy : Form
    {
        public DivideProxy()
        {
            InitializeComponent();
        }
     
        public delegate void DivideEventHandler(object sender, OperationEventArgs a);
        public DivideEventHandler divideEventHandler;

        public Subject proxy = new Proxy();

        private void m_btnDivideNumbers_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(m_tbDivideX.Text);
            double y = Convert.ToDouble(m_tbDivideY.Text);

            double d_answer = proxy.Divide(x, y);
            string s_answer = Convert.ToString(d_answer);

            if (m_tbDivideX.Text.Length != null && m_tbDivideY.Text.Length != null)
            {
                if (divideEventHandler != null)
                    divideEventHandler(this, new OperationEventArgs(s_answer));
            }
        }   
    }
}
