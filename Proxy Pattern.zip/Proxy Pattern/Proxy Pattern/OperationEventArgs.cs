﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy_Pattern
{
    public class OperationEventArgs : EventArgs
    {
        private string _answer;

            public string m_answer
            {
                get { return _answer; }
                set { _answer = value; }
            }

            public OperationEventArgs(string answer)
            {
                _answer = answer;
            }
    }
}
