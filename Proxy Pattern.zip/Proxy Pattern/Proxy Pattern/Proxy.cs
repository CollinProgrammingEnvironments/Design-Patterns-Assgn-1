﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy_Pattern
{
    public class Proxy : Subject
    {
        private RealSubject _rsubject = new RealSubject();

        public double Add(double x, double y)
        {
            return _rsubject.Add(x, y);
        }
        public double Subtract(double x, double y)
        {
            return _rsubject.Subtract(x, y);
        }
        public double Multiply(double x, double y)
        {
            return _rsubject.Multiply(x, y);
        }
        public double Divide(double x, double y)
        {
            return _rsubject.Divide(x, y);
        }

    }

}
