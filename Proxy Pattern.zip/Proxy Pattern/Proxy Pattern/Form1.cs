﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proxy_Pattern
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        AddProxy addproxy = new AddProxy();
        SubtractProxy subproxy = new SubtractProxy();
        MultiplyProxy multproxy = new MultiplyProxy();
        DivideProxy divproxy = new DivideProxy();

        private void m_btnAdd_Click(object sender, EventArgs e)
        {
            addproxy.addEventHandler += new AddProxy.AddEventHandler(operationproxy_operationEventHandler);
            addproxy.StartPosition = FormStartPosition.CenterScreen;
            addproxy.Show();

            m_tbAnswer.Text = "";
        }

        private void m_btnSubtract_Click(object sender, EventArgs e)
        {
            subproxy.subtractEventHandler += new SubtractProxy.SubtractEventHandler(operationproxy_operationEventHandler);
            subproxy.StartPosition = FormStartPosition.CenterScreen;
            subproxy.Show();

            m_tbAnswer.Text = "";
        }

        private void m_btnMultiply_Click(object sender, EventArgs e)
        {
            multproxy.multiplyEventHandler += new MultiplyProxy.MultiplyEventHandler(operationproxy_operationEventHandler);
            multproxy.StartPosition = FormStartPosition.CenterScreen;
            multproxy.Show(this);

            m_tbAnswer.Text = "";
        }

        private void m_btnDivide_Click(object sender, EventArgs e)
        {
            divproxy.divideEventHandler += new DivideProxy.DivideEventHandler(operationproxy_operationEventHandler);
            divproxy.StartPosition = FormStartPosition.CenterScreen;
            divproxy.Show(this);

            m_tbAnswer.Text = "";
        }

        private void operationproxy_operationEventHandler(object sender, OperationEventArgs a)
        {
            string newValue;

            newValue = a.m_answer;
            m_tbAnswer.Text = newValue;
        }
    }
}
