﻿namespace Proxy_Pattern
{
    partial class AddProxy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_tbAddX = new System.Windows.Forms.TextBox();
            this.m_tbAddY = new System.Windows.Forms.TextBox();
            this.m_lbAddX = new System.Windows.Forms.Label();
            this.m_lbAddY = new System.Windows.Forms.Label();
            this.m_lbAddTitle = new System.Windows.Forms.Label();
            this.m_btnAddNumbers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_tbAddX
            // 
            this.m_tbAddX.Location = new System.Drawing.Point(43, 119);
            this.m_tbAddX.Name = "m_tbAddX";
            this.m_tbAddX.Size = new System.Drawing.Size(73, 20);
            this.m_tbAddX.TabIndex = 0;
            // 
            // m_tbAddY
            // 
            this.m_tbAddY.Location = new System.Drawing.Point(158, 119);
            this.m_tbAddY.Name = "m_tbAddY";
            this.m_tbAddY.Size = new System.Drawing.Size(79, 20);
            this.m_tbAddY.TabIndex = 1;
            // 
            // m_lbAddX
            // 
            this.m_lbAddX.AutoSize = true;
            this.m_lbAddX.Location = new System.Drawing.Point(40, 92);
            this.m_lbAddX.Name = "m_lbAddX";
            this.m_lbAddX.Size = new System.Drawing.Size(66, 13);
            this.m_lbAddX.TabIndex = 2;
            this.m_lbAddX.Text = "First Number";
            // 
            // m_lbAddY
            // 
            this.m_lbAddY.AutoSize = true;
            this.m_lbAddY.Location = new System.Drawing.Point(155, 92);
            this.m_lbAddY.Name = "m_lbAddY";
            this.m_lbAddY.Size = new System.Drawing.Size(84, 13);
            this.m_lbAddY.TabIndex = 3;
            this.m_lbAddY.Text = "Second Number";
            // 
            // m_lbAddTitle
            // 
            this.m_lbAddTitle.AutoSize = true;
            this.m_lbAddTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lbAddTitle.Location = new System.Drawing.Point(45, 40);
            this.m_lbAddTitle.Name = "m_lbAddTitle";
            this.m_lbAddTitle.Size = new System.Drawing.Size(180, 24);
            this.m_lbAddTitle.TabIndex = 4;
            this.m_lbAddTitle.Text = "Add two numbers!";
            // 
            // m_btnAddNumbers
            // 
            this.m_btnAddNumbers.Location = new System.Drawing.Point(92, 180);
            this.m_btnAddNumbers.Name = "m_btnAddNumbers";
            this.m_btnAddNumbers.Size = new System.Drawing.Size(82, 26);
            this.m_btnAddNumbers.TabIndex = 5;
            this.m_btnAddNumbers.Text = "Add!";
            this.m_btnAddNumbers.UseVisualStyleBackColor = true;
            this.m_btnAddNumbers.Click += new System.EventHandler(this.m_btnAddNumbers_Click);
            // 
            // AddProxy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.m_btnAddNumbers);
            this.Controls.Add(this.m_lbAddTitle);
            this.Controls.Add(this.m_lbAddY);
            this.Controls.Add(this.m_lbAddX);
            this.Controls.Add(this.m_tbAddY);
            this.Controls.Add(this.m_tbAddX);
            this.Name = "AddProxy";
            this.Text = "AddProxy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_tbAddX;
        private System.Windows.Forms.TextBox m_tbAddY;
        private System.Windows.Forms.Label m_lbAddX;
        private System.Windows.Forms.Label m_lbAddY;
        private System.Windows.Forms.Label m_lbAddTitle;
        private System.Windows.Forms.Button m_btnAddNumbers;
    }
}