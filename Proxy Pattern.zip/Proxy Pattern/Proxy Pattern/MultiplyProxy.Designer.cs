﻿namespace Proxy_Pattern
{
    partial class MultiplyProxy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_btnMultiplyNumbers = new System.Windows.Forms.Button();
            this.m_lbMultiplyTitle = new System.Windows.Forms.Label();
            this.m_lbMultiplyY = new System.Windows.Forms.Label();
            this.m_lbMultiplyX = new System.Windows.Forms.Label();
            this.m_tbMultiplyY = new System.Windows.Forms.TextBox();
            this.m_tbMultiplyX = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_btnMultiplyNumbers
            // 
            this.m_btnMultiplyNumbers.Location = new System.Drawing.Point(95, 188);
            this.m_btnMultiplyNumbers.Name = "m_btnMultiplyNumbers";
            this.m_btnMultiplyNumbers.Size = new System.Drawing.Size(82, 26);
            this.m_btnMultiplyNumbers.TabIndex = 17;
            this.m_btnMultiplyNumbers.Text = "Multiply!";
            this.m_btnMultiplyNumbers.UseVisualStyleBackColor = true;
            this.m_btnMultiplyNumbers.Click += new System.EventHandler(this.m_btnMultiplyNumbers_Click);
            // 
            // m_lbMultiplyTitle
            // 
            this.m_lbMultiplyTitle.AutoSize = true;
            this.m_lbMultiplyTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lbMultiplyTitle.Location = new System.Drawing.Point(33, 46);
            this.m_lbMultiplyTitle.Name = "m_lbMultiplyTitle";
            this.m_lbMultiplyTitle.Size = new System.Drawing.Size(213, 24);
            this.m_lbMultiplyTitle.TabIndex = 16;
            this.m_lbMultiplyTitle.Text = "Multiply two numbers!";
            // 
            // m_lbMultiplyY
            // 
            this.m_lbMultiplyY.AutoSize = true;
            this.m_lbMultiplyY.Location = new System.Drawing.Point(158, 100);
            this.m_lbMultiplyY.Name = "m_lbMultiplyY";
            this.m_lbMultiplyY.Size = new System.Drawing.Size(84, 13);
            this.m_lbMultiplyY.TabIndex = 15;
            this.m_lbMultiplyY.Text = "Second Number";
            // 
            // m_lbMultiplyX
            // 
            this.m_lbMultiplyX.AutoSize = true;
            this.m_lbMultiplyX.Location = new System.Drawing.Point(43, 100);
            this.m_lbMultiplyX.Name = "m_lbMultiplyX";
            this.m_lbMultiplyX.Size = new System.Drawing.Size(66, 13);
            this.m_lbMultiplyX.TabIndex = 14;
            this.m_lbMultiplyX.Text = "First Number";
            // 
            // m_tbMultiplyY
            // 
            this.m_tbMultiplyY.Location = new System.Drawing.Point(161, 127);
            this.m_tbMultiplyY.Name = "m_tbMultiplyY";
            this.m_tbMultiplyY.Size = new System.Drawing.Size(79, 20);
            this.m_tbMultiplyY.TabIndex = 13;
            // 
            // m_tbMultiplyX
            // 
            this.m_tbMultiplyX.Location = new System.Drawing.Point(46, 127);
            this.m_tbMultiplyX.Name = "m_tbMultiplyX";
            this.m_tbMultiplyX.Size = new System.Drawing.Size(73, 20);
            this.m_tbMultiplyX.TabIndex = 12;
            // 
            // MultiplyProxy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.m_btnMultiplyNumbers);
            this.Controls.Add(this.m_lbMultiplyTitle);
            this.Controls.Add(this.m_lbMultiplyY);
            this.Controls.Add(this.m_lbMultiplyX);
            this.Controls.Add(this.m_tbMultiplyY);
            this.Controls.Add(this.m_tbMultiplyX);
            this.Name = "MultiplyProxy";
            this.Text = "MultiplyProxy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnMultiplyNumbers;
        private System.Windows.Forms.Label m_lbMultiplyTitle;
        private System.Windows.Forms.Label m_lbMultiplyY;
        private System.Windows.Forms.Label m_lbMultiplyX;
        private System.Windows.Forms.TextBox m_tbMultiplyY;
        private System.Windows.Forms.TextBox m_tbMultiplyX;
    }
}