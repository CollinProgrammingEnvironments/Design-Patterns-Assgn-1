﻿namespace Proxy_Pattern
{
    partial class SubtractProxy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_btnSubtractNumbers = new System.Windows.Forms.Button();
            this.m_lbSubtractTitle = new System.Windows.Forms.Label();
            this.m_lbSubtractY = new System.Windows.Forms.Label();
            this.m_lbSubtractX = new System.Windows.Forms.Label();
            this.m_tbSubtractY = new System.Windows.Forms.TextBox();
            this.m_tbSubtractX = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_btnSubtractNumbers
            // 
            this.m_btnSubtractNumbers.Location = new System.Drawing.Point(95, 187);
            this.m_btnSubtractNumbers.Name = "m_btnSubtractNumbers";
            this.m_btnSubtractNumbers.Size = new System.Drawing.Size(82, 26);
            this.m_btnSubtractNumbers.TabIndex = 11;
            this.m_btnSubtractNumbers.Text = "Subtract!";
            this.m_btnSubtractNumbers.UseVisualStyleBackColor = true;
            this.m_btnSubtractNumbers.Click += new System.EventHandler(this.m_btnSubtractNumbers_Click);
            // 
            // m_lbSubtractTitle
            // 
            this.m_lbSubtractTitle.AutoSize = true;
            this.m_lbSubtractTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lbSubtractTitle.Location = new System.Drawing.Point(33, 45);
            this.m_lbSubtractTitle.Name = "m_lbSubtractTitle";
            this.m_lbSubtractTitle.Size = new System.Drawing.Size(218, 24);
            this.m_lbSubtractTitle.TabIndex = 10;
            this.m_lbSubtractTitle.Text = "Subtract two numbers!";
            // 
            // m_lbSubtractY
            // 
            this.m_lbSubtractY.AutoSize = true;
            this.m_lbSubtractY.Location = new System.Drawing.Point(158, 99);
            this.m_lbSubtractY.Name = "m_lbSubtractY";
            this.m_lbSubtractY.Size = new System.Drawing.Size(84, 13);
            this.m_lbSubtractY.TabIndex = 9;
            this.m_lbSubtractY.Text = "Second Number";
            // 
            // m_lbSubtractX
            // 
            this.m_lbSubtractX.AutoSize = true;
            this.m_lbSubtractX.Location = new System.Drawing.Point(43, 99);
            this.m_lbSubtractX.Name = "m_lbSubtractX";
            this.m_lbSubtractX.Size = new System.Drawing.Size(66, 13);
            this.m_lbSubtractX.TabIndex = 8;
            this.m_lbSubtractX.Text = "First Number";
            // 
            // m_tbSubtractY
            // 
            this.m_tbSubtractY.Location = new System.Drawing.Point(161, 126);
            this.m_tbSubtractY.Name = "m_tbSubtractY";
            this.m_tbSubtractY.Size = new System.Drawing.Size(79, 20);
            this.m_tbSubtractY.TabIndex = 7;
            // 
            // m_tbSubtractX
            // 
            this.m_tbSubtractX.Location = new System.Drawing.Point(46, 126);
            this.m_tbSubtractX.Name = "m_tbSubtractX";
            this.m_tbSubtractX.Size = new System.Drawing.Size(73, 20);
            this.m_tbSubtractX.TabIndex = 6;
            // 
            // SubtractProxy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.m_btnSubtractNumbers);
            this.Controls.Add(this.m_lbSubtractTitle);
            this.Controls.Add(this.m_lbSubtractY);
            this.Controls.Add(this.m_lbSubtractX);
            this.Controls.Add(this.m_tbSubtractY);
            this.Controls.Add(this.m_tbSubtractX);
            this.Name = "SubtractProxy";
            this.Text = "SubtractProxy";
            this.Click += new System.EventHandler(this.m_btnSubtractNumbers_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnSubtractNumbers;
        private System.Windows.Forms.Label m_lbSubtractTitle;
        private System.Windows.Forms.Label m_lbSubtractY;
        private System.Windows.Forms.Label m_lbSubtractX;
        private System.Windows.Forms.TextBox m_tbSubtractY;
        private System.Windows.Forms.TextBox m_tbSubtractX;
    }
}