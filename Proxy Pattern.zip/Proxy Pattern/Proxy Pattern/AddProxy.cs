﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proxy_Pattern
{
    public partial class AddProxy : Form
    {
        public AddProxy()
        {
            InitializeComponent();
        }

        public delegate void AddEventHandler(object sender, OperationEventArgs a);
        public AddEventHandler addEventHandler;

        public Proxy proxy = new Proxy();

        public void m_btnAddNumbers_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(m_tbAddX.Text);
            double y = Convert.ToDouble(m_tbAddY.Text);

            double d_answer = proxy.Add(x, y);
            string s_answer = Convert.ToString(d_answer);

            if (m_tbAddX.Text.Length != null && m_tbAddY.Text.Length != null)
            {                                         
                if (addEventHandler != null)
                    addEventHandler(this, new OperationEventArgs(s_answer));
            }
        }
    }
}
