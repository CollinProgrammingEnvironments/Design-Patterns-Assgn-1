﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proxy_Pattern
{
    public partial class MultiplyProxy : Form
    {
        public MultiplyProxy()
        {
            InitializeComponent();
        }
       
        public delegate void MultiplyEventHandler(object sender, OperationEventArgs a);
        public MultiplyEventHandler multiplyEventHandler;

        public Proxy proxy = new Proxy();

        private void m_btnMultiplyNumbers_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(m_tbMultiplyX.Text);
            double y = Convert.ToDouble(m_tbMultiplyY.Text);

            double d_answer = proxy.Multiply(x, y);
            string s_answer = Convert.ToString(d_answer);

            if (m_tbMultiplyX.Text.Length != null && m_tbMultiplyY.Text.Length != null)
            {
                if (multiplyEventHandler != null)
                    multiplyEventHandler(this, new OperationEventArgs(s_answer));
            }
        }
    }
}
