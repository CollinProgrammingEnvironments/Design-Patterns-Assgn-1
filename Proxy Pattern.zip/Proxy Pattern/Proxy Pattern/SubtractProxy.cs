﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proxy_Pattern
{
    public partial class SubtractProxy : Form
    {
        public SubtractProxy()
        {
            InitializeComponent();
        }

        public delegate void SubtractEventHandler(object sender, OperationEventArgs a);
        public SubtractEventHandler subtractEventHandler;

        public Subject proxy = new Proxy();

        public void m_btnSubtractNumbers_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(m_tbSubtractX.Text);
            double y = Convert.ToDouble(m_tbSubtractY.Text);

            double d_answer = proxy.Subtract(x, y);
            string s_answer = Convert.ToString(d_answer);

            if (m_tbSubtractX.Text.Length != null && m_tbSubtractY.Text.Length != null)
            {
                if (subtractEventHandler != null)
                    subtractEventHandler(this, new OperationEventArgs(s_answer));
            }
        }
    }
}
