﻿namespace Proxy_Pattern
{
    partial class DivideProxy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_btnDivideNumbers = new System.Windows.Forms.Button();
            this.m_lbDivideTitle = new System.Windows.Forms.Label();
            this.m_lbDivideY = new System.Windows.Forms.Label();
            this.m_lbDivideX = new System.Windows.Forms.Label();
            this.m_tbDivideY = new System.Windows.Forms.TextBox();
            this.m_tbDivideX = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_btnDivideNumbers
            // 
            this.m_btnDivideNumbers.Location = new System.Drawing.Point(98, 188);
            this.m_btnDivideNumbers.Name = "m_btnDivideNumbers";
            this.m_btnDivideNumbers.Size = new System.Drawing.Size(82, 26);
            this.m_btnDivideNumbers.TabIndex = 23;
            this.m_btnDivideNumbers.Text = "Divide!";
            this.m_btnDivideNumbers.UseVisualStyleBackColor = true;
            this.m_btnDivideNumbers.Click += new System.EventHandler(this.m_btnDivideNumbers_Click);
            // 
            // m_lbDivideTitle
            // 
            this.m_lbDivideTitle.AutoSize = true;
            this.m_lbDivideTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lbDivideTitle.Location = new System.Drawing.Point(45, 46);
            this.m_lbDivideTitle.Name = "m_lbDivideTitle";
            this.m_lbDivideTitle.Size = new System.Drawing.Size(200, 24);
            this.m_lbDivideTitle.TabIndex = 22;
            this.m_lbDivideTitle.Text = "Divide two numbers!";
            // 
            // m_lbDivideY
            // 
            this.m_lbDivideY.AutoSize = true;
            this.m_lbDivideY.Location = new System.Drawing.Point(161, 100);
            this.m_lbDivideY.Name = "m_lbDivideY";
            this.m_lbDivideY.Size = new System.Drawing.Size(84, 13);
            this.m_lbDivideY.TabIndex = 21;
            this.m_lbDivideY.Text = "Second Number";
            // 
            // m_lbDivideX
            // 
            this.m_lbDivideX.AutoSize = true;
            this.m_lbDivideX.Location = new System.Drawing.Point(46, 100);
            this.m_lbDivideX.Name = "m_lbDivideX";
            this.m_lbDivideX.Size = new System.Drawing.Size(66, 13);
            this.m_lbDivideX.TabIndex = 20;
            this.m_lbDivideX.Text = "First Number";
            // 
            // m_tbDivideY
            // 
            this.m_tbDivideY.Location = new System.Drawing.Point(164, 127);
            this.m_tbDivideY.Name = "m_tbDivideY";
            this.m_tbDivideY.Size = new System.Drawing.Size(79, 20);
            this.m_tbDivideY.TabIndex = 19;
            // 
            // m_tbDivideX
            // 
            this.m_tbDivideX.Location = new System.Drawing.Point(49, 127);
            this.m_tbDivideX.Name = "m_tbDivideX";
            this.m_tbDivideX.Size = new System.Drawing.Size(73, 20);
            this.m_tbDivideX.TabIndex = 18;
            // 
            // DivideProxy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.m_btnDivideNumbers);
            this.Controls.Add(this.m_lbDivideTitle);
            this.Controls.Add(this.m_lbDivideY);
            this.Controls.Add(this.m_lbDivideX);
            this.Controls.Add(this.m_tbDivideY);
            this.Controls.Add(this.m_tbDivideX);
            this.Name = "DivideProxy";
            this.Text = "DivideProxy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_btnDivideNumbers;
        private System.Windows.Forms.Label m_lbDivideTitle;
        private System.Windows.Forms.Label m_lbDivideY;
        private System.Windows.Forms.Label m_lbDivideX;
        private System.Windows.Forms.TextBox m_tbDivideY;
        private System.Windows.Forms.TextBox m_tbDivideX;
    }
}